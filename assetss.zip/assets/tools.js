/* LovePDFi /assets/tools.js
 * - Always: hamburger menu
 * - When body[data-shared-app="1"]: full homepage tool application (from index.html)
 * Tool pages keep their own inline app scripts; they still load this file for chrome + future shared APIs.
 */
(function(){
  var burger=document.getElementById('burger');
  var nav=document.getElementById('nav');
  if(burger&&nav){
    burger.addEventListener('click',function(){
      var open=nav.classList.toggle('show');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
})();


/* Full shared app — runs only on pages marked data-shared-app="1" (homepage) */
if (document.body && document.body.getAttribute('data-shared-app') === '1') {
(function(){
(function(){var bar=document.getElementById('atlBar');if(!bar)return;bar.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var c=b.getAttribute('data-cat');bar.querySelectorAll('button').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')});document.querySelectorAll('.atl-card').forEach(function(a){a.hidden=!(c==='all'||(' '+a.getAttribute('data-cat')+' ').indexOf(' '+c+' ')>-1)})})})();
;
(function(){
 var $=function(i){return document.getElementById(i)},Q=function(s){return document.querySelectorAll(s)};
 // Give every generated download a filename based on the user's local device time.
 function easyToolsTimestampFilename(name){
  name=String(name||'download');
  var dot=name.lastIndexOf('.'),ext=(dot>0?name.slice(dot):''),stem=(dot>0?name.slice(0,dot):name);
  var d=new Date(),pad=function(n,w){return String(n).padStart(w||2,'0')};
  var stamp=d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'_'+pad(d.getHours())+'-'+pad(d.getMinutes())+'-'+pad(d.getSeconds())+'-'+pad(d.getMilliseconds(),3);
  return stem+'_'+stamp+ext;
 }
 // Capture regular and programmatic anchor downloads, including PDF and ZIP outputs.
 document.addEventListener('click',function(ev){
  var node=ev.target,link=node&&node.closest?node.closest('a[download]'):null;
  if(!link)return;
  var base=link.getAttribute('data-et-base-name');
  if(!base){base=link.getAttribute('download')||link.download;if(!base)return;link.setAttribute('data-et-base-name',base);}
  link.download=easyToolsTimestampFilename(base);
 },true);

 var burger=$('burger'),nav=$('nav');
 burger.onclick=function(){var s=nav.classList.toggle('show');burger.setAttribute('aria-expanded',s)};
 var cur='images',file=null,img=null,fmt='jpeg',ratio=1,url=null,msg=$('msg');
 function show(t){
  cur=t;
  Q('.tab').forEach(function(b){b.setAttribute('aria-selected',b.dataset.tab===t)});
  Q('[data-panel]').forEach(function(p){p.hidden=p.dataset.panel!==t});
  var text={images:'Image tools: compress, convert or resize.',pdf:'PDF tools: compress, merge, split, or make a PDF from photos.',files:'Excel / CSV tools: select your file, then choose the available conversion.',qrtools:'QR tools: create a QR code or decode a QR image to text.'};
  $('sub').textContent=text[t]||''; msg.textContent='';$('done').classList.remove('show');
 }
 function showSub(panel,key){var root=document.querySelector('[data-panel="'+panel+'"]');if(!root)return;root.querySelectorAll('.subtab').forEach(function(b){b.classList.toggle('active',b.dataset.sub===key)});root.querySelectorAll('[data-subpanel]').forEach(function(p){p.hidden=p.dataset.subpanel!==key});if(panel==='pdf'&&window.PDFShared&&window.PDFShared.onTool)window.PDFShared.onTool(key);}

 var URLS={imgc:'https://cdn.jsdelivr.net/npm/browser-image-compression@2.0.2/dist/browser-image-compression.js',qr:'https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js',jsqr:'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js',pdflib:'https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js',pdfjs:'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',xlsx:'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',jspdf:'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',atable:'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js',jszip:'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',heic:'https://cdn.jsdelivr.net/npm/heic2any@0.0.4/dist/heic2any.min.js'};
 var SETS={images:['imgc'],pdf:['pdflib','pdfjs'],files:['xlsx','jspdf','atable'],qrtools:['qr','jsqr']};
 var _p={},ready={};
 function lj(k){return _p[k]||(_p[k]=new Promise(function(res,rej){if(document.querySelector('script[data-lp-lib="'+k+'"]')){res();return}var s=document.createElement('script');s.src=URLS[k];s.async=true;s.dataset.lpLib=k;s.onload=function(){if(k==='pdfjs'&&window.pdfjsLib){try{pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'}catch(e){}}res()};s.onerror=function(){delete _p[k];rej(new Error('Failed to load '+k))};document.head.appendChild(s)}))}
 function toolLoadingMsg(on,label){var el=document.getElementById('msg');if(!el)return;if(on){el.dataset.loadingTool='1';el.textContent=label||'Loading tool…';}else if(el.dataset.loadingTool){delete el.dataset.loadingTool;if(/^Loading tool/.test(el.textContent||''))el.textContent='';}}function loadFor(t){if(ready[t])return Promise.resolve();var labels={images:'Loading image tools…',pdf:'Loading PDF tools…',files:'Loading spreadsheet tools…',qrtools:'Loading QR tools…'};toolLoadingMsg(true,labels[t]||'Loading tool…');return (SETS[t]||[]).reduce(function(p,k){return p.then(function(){return lj(k)})},Promise.resolve()).then(function(){ready[t]=true;toolLoadingMsg(false)}).catch(function(e){toolLoadingMsg(false);throw e})}
 /* Tab UI switches immediately; heavy libraries load only when a tool actually needs them. */
var _show=show;show=function(t){_show(t)};
 function guard(e){var t=e.target;if(!t||!t.closest||ready[cur])return;
  var isRun=e.type==='click'&&t.closest('.btn.out'),isFile=e.type==='change'&&t.type==='file',isDrop=e.type==='drop'&&t.closest('.drop');
  if(!(isRun||isFile||isDrop))return;
  e.stopImmediatePropagation();e.preventDefault();msg.textContent='Loading tools…';
  loadFor(cur).then(function(){msg.textContent='';if(isRun)t.click();else if(isFile)t.dispatchEvent(new Event('change',{bubbles:true}));else msg.textContent='Tools are ready. Please drop the file again.'},function(){err('Could not load the tools. Check your internet connection and try again.')})}
 ['click','change','drop'].forEach(function(v){document.addEventListener(v,guard,true)});
 var D=document.body.dataset;
 show(D.tab||'images');if(D.sub)showSub(D.tab,D.sub);
 Q('.tab').forEach(function(b){b.onclick=function(){show(b.dataset.tab)}});
 Q('.subtab').forEach(function(b){b.onclick=function(){var root=b.closest('[data-panel]');showSub(root.dataset.panel,b.dataset.sub)}});
 // Tool cards select the matching tool in this shared tool area instead of
 // navigating away and leaving the other tools unavailable on a standalone index.html.
 var cardTools={
  'compress-image-to-50kb':{tab:'images',sub:'compress',kb:'50'},
  'compress-image-to-100kb':{tab:'images',sub:'compress',kb:'100'},
  'compress-image-to-200kb':{tab:'images',sub:'compress',kb:'200'},
  'compress-image-to-500kb':{tab:'images',sub:'compress',kb:'500'},
  'compress-multiple-images':{tab:'images',sub:'compress',batch:true},
  'compress-image-from-camera':{tab:'images',sub:'compress',camera:true,kb:'100'},
  'resize-image-to-413x531':{tab:'images',sub:'resize',w:'413',h:'531'},
  'jpg-to-png':{tab:'images',sub:'convert',fmt:'png'},
  'png-to-jpg':{tab:'images',sub:'convert',fmt:'jpeg'},
  'webp-to-jpg':{tab:'images',sub:'convert',fmt:'jpeg'},
  'heic-to-jpg':{tab:'images',sub:'heic',fmt:'jpeg'},
  'heic-to-png':{tab:'images',sub:'heic',fmt:'png'},
  'image-to-pdf':{tab:'pdf',sub:'imgpdf'},
  'pdf-to-image':{tab:'pdf',sub:'pdfimg'},
  'camera-to-pdf':{tab:'pdf',sub:'scan',camera:true},
  'document-scanner-online':{tab:'pdf',sub:'scan'},
  'merge-pdf':{tab:'pdf',sub:'pdfmerge'},
  'split-pdf':{tab:'pdf',sub:'pdfsplit'},
  'edit-pdf-online':{tab:'pdf',sub:'pdfedit'},
  'compress-pdf':{tab:'pdf',sub:'pdfcompress'},
  'excel-to-pdf':{tab:'files',sub:'fileconvert',mode:'pdf'},
  'excel-to-csv':{tab:'files',sub:'fileconvert',mode:'csv'},
  'csv-to-excel':{tab:'files',sub:'fileconvert',mode:'xlsx'},
  'text-to-qr-code':{tab:'qrtools',sub:'createqr'},
  'link-to-qr-code':{tab:'qrtools',sub:'createqr'},
  'qr-code-scanner-online':{tab:'qrtools',sub:'decodeqr',camera:true},
  'qr-code-reader':{tab:'qrtools',sub:'decodeqr'}
 };
 function chooseCardTool(a){
  var raw=a.getAttribute('href')||'',slug=raw.split('#')[0].split('?')[0].replace(/\/$/,'').split('/').pop();
  var cfg=cardTools[slug];if(!cfg)return false;
  show(cfg.tab);showSub(cfg.tab,cfg.sub);
  if(cfg.kb){$('kb').value=cfg.kb;Q('[data-kb]').forEach(function(x){x.setAttribute('aria-pressed',x.dataset.kb===cfg.kb?'true':'false')});}
  if(cfg.fmt){fmt=cfg.fmt;Q('[data-fmt]').forEach(function(x){x.setAttribute('aria-pressed',x.dataset.fmt===cfg.fmt?'true':'false')});}
  if(cfg.w){$('rw').value=cfg.w;$('rh').value=cfg.h;$('lock').checked=false;}
  if(cfg.batch){var batch=$('batchinfo');if(batch){batch.hidden=false;batch.textContent='Multiple images mode: select several images together. The same compression settings apply to the selected batch.';}}
  if(cfg.mode){ecMode=cfg.mode;['toCsv','toXlsx','toPdf'].forEach(function(id){var el=$(id);if(el)el.setAttribute('aria-pressed',(id==='toCsv'&&cfg.mode==='csv'||id==='toXlsx'&&cfg.mode==='xlsx'||id==='toPdf'&&cfg.mode==='pdf')?'true':'false')});}
  nav.classList.remove('show');
  var target=$('tool');if(target){target.scrollIntoView({behavior:'smooth',block:'start'});}
  if(cfg.camera){setTimeout(function(){var id=cfg.tab==='images'?'camshot':cfg.tab==='pdf'?'scCam':'qrcam';var btn=$(id);if(btn)btn.focus({preventScroll:true});},350);}
  return true;
 }
 /* atl-cards navigate to dedicated tool pages; keep chooseCardTool for in-page use if needed */
 /* Q('.atl-card') navigation enabled: no preventDefault */

 Q('[data-go]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();var t=a.dataset.go||'images';show(t);nav.classList.remove('show')})});

 function size(b){return b>=1048576?(b/1048576).toFixed(2)+' MB':(b/1024).toFixed(1)+' KB'}
 function err(t){msg.innerHTML='<span class="err">'+t+'</span>'}
 function runs(on){Q('[data-run=compress],[data-run=convert],[data-run=resize]').forEach(function(b){b.disabled=!on})}
 var drop=$('drop'),inp=$('file'),tu=null;
 function clear(){file=null;img=null;inp.value='';$('thumb').hidden=true;if($('imgPrev'))$('imgPrev').hidden=true;if($('imgGrid')){$('imgGrid').hidden=true;$('imgGrid').innerHTML=''}drop.hidden=false;hideBadge();runs(false);msg.textContent='';$('done').classList.remove('show');if(tu)URL.revokeObjectURL(tu);resetBatch()}

 var LBL={jpg:'JPG',png:'PNG',webp:'WebP',gif:'GIF',bmp:'BMP',avif:'AVIF',tiff:'TIFF',heic:'HEIC (iPhone photo)'},MIME={jpg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',bmp:'image/bmp',avif:'image/avif',tiff:'image/tiff'};
 async function sniff(f){
  var b=new Uint8Array(await f.slice(0,16).arrayBuffer()),s=function(a,e){var r='';for(var i=a;i<e;i++)r+=String.fromCharCode(b[i]);return r};
  if(b[0]===0xFF&&b[1]===0xD8)return 'jpg';
  if(b[0]===0x89&&s(1,4)==='PNG')return 'png';
  if(s(0,4)==='RIFF'&&s(8,12)==='WEBP')return 'webp';
  if(s(0,3)==='GIF')return 'gif';
  if(s(0,2)==='BM')return 'bmp';
  if(s(4,8)==='ftyp'){var br=s(8,12);if(/^(heic|heix|hevc|hevx|heim|heis|mif1|msf1|heif)/.test(br))return 'heic';if(br==='avif'||br==='avis')return 'avif'}
  if((b[0]===0x49&&b[1]===0x49&&b[2]===0x2A)||(b[0]===0x4D&&b[1]===0x4D&&b[3]===0x2A))return 'tiff';
  return ''}
 var _nc=new WeakMap();
 async function normImg(f){
  if(_nc.has(f))return _nc.get(f);
  var k=await sniff(f);
  if(!k&&/\.(heic|heif)$/i.test(f.name))k='heic';
  if(!k&&/^image\//.test(f.type))k=({'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','image/bmp':'bmp','image/avif':'avif'})[f.type]||'';
  if(!k)throw new Error('bad');
  var out={file:f,kind:k,converted:false};
  if(k==='heic'){
   msg.textContent='iPhone HEIC photo detected. Converting… this can take a few seconds.';
   var jb=null;
   try{
    var L=await new Promise(function(res,rej){var u=URL.createObjectURL(f),i=new Image();i.onload=function(){res({i:i,u:u})};i.onerror=function(){URL.revokeObjectURL(u);rej()};i.src=u});
    var c=document.createElement('canvas');c.width=L.i.naturalWidth;c.height=L.i.naturalHeight;var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(L.i,0,0);URL.revokeObjectURL(L.u);
    jb=await new Promise(function(r){c.toBlob(r,'image/jpeg',0.95)});c.width=c.height=1;
   }catch(e){jb=null}
   if(!jb){
    toolLoadingMsg(true,'Loading HEIC decoder…');await lj('heic');toolLoadingMsg(false);
    var r=await window.heic2any({blob:f,toType:'image/jpeg',quality:0.95});
    jb=Array.isArray(r)?r[0]:r}
   out.file=new File([jb],f.name.replace(/\.(heic|heif)$/i,'')+'.jpg',{type:'image/jpeg'});out.converted=true;
  }else if(!f.type&&MIME[k]){out.file=new File([f],f.name,{type:MIME[k]})}
  _nc.set(f,out);return out}
 async function normAll(list){
  var files=[],kinds=[],bad=0;
  for(var q=0;q<list.length;q++){
   msg.textContent='Reading image '+(q+1)+' of '+list.length+'…';
   try{var n=await normImg(list[q]);files.push(n.file);kinds.push(n.kind)}catch(e){bad++}}
  msg.textContent='';return {files:files,kinds:kinds,bad:bad}}
 function kindsText(kinds){var c={};kinds.forEach(function(k){c[k]=(c[k]||0)+1});return Object.keys(c).map(function(k){return c[k]+' '+(LBL[k]||k)}).join(', ')}
 function showBadge(txt){var b=$('fmtbadge');b.innerHTML=txt;b.hidden=false;$('quickfmt').hidden=false}
 function hideBadge(){$('fmtbadge').hidden=true;$('quickfmt').hidden=true}
 Q('[data-qf]').forEach(function(c){c.onclick=function(){
  fmt=c.dataset.qf;Q('[data-fmt]').forEach(function(x){x.setAttribute('aria-pressed',x.dataset.fmt===fmt?'true':'false')});
  showSub('images','convert');var rb=document.querySelector('[data-run="convert"]');if(rb&&!rb.disabled)rb.click()}});
 function pickOld(f0){resetBatch();hideBadge();if(!f0)return;
  normImg(f0).then(function(n){msg.textContent='';pick2(n.file,n)}).catch(function(e){msg.textContent='';err(e&&e.message==='bad'?'Please choose an image file (JPG, PNG, WebP or iPhone HEIC).':'This photo could not be read. If it is a HEIC photo, try again, or export it as JPG from your phone.')})}
 function pick2(f,n){
  var u=URL.createObjectURL(f),i=new Image();
  i.onload=function(){file=f;img=i;if(tu)URL.revokeObjectURL(tu);tu=u;
   $('timg').src=u;$('tname').textContent=f.name+' · '+size(f.size)+' · '+i.naturalWidth+'×'+i.naturalHeight;
   $('thumb').hidden=true;if($('imgPrev'))$('imgPrev').hidden=false;if($('imgGrid'))$('imgGrid').hidden=true;drop.hidden=true;
   showBadge('Detected format: <b>'+(LBL[n.kind]||n.kind)+'</b>'+(n.converted?' · converted to JPG so it works everywhere':''));
   ratio=i.naturalWidth/i.naturalHeight;if(!D.w){$('rw').value=i.naturalWidth;$('rh').value=i.naturalHeight}
   runs(true);upd();setTimeout(updateResizeOverlay,40);msg.textContent='';$('done').classList.remove('show')};
  i.onerror=function(){URL.revokeObjectURL(u);err('This image could not be read. Try a different file.')};
  i.src=u;
 }
 if($('timg')){$('timg').onclick=function(){if(this.src)lbShow(this.src)};$('timg').style.cursor='zoom-in'}
 if($('imgPrevStage'))$('imgPrevStage').ondblclick=function(){var s=$('timg')&&$('timg').src;if(s)lbShow(s)};
 if($('imgPrevFs'))$('imgPrevFs').onclick=function(){var s=$('timg')&&$('timg').src;if(s)lbShow(s)};
 async function imgDoRot(deg){var f=file;if(!f||!window.rotBlob)return;try{var bl=await window.rotBlob(f,deg);var nf=new File([bl],f.name.replace(/\.[^.]+$/,'')+'.jpg',{type:'image/jpeg'});file=nf;if(tu)URL.revokeObjectURL(tu);tu=URL.createObjectURL(nf);$('timg').src=tu;$('tname').textContent=nf.name}catch(e){err('Could not rotate the image.')}}
 if($('imgPrevRL'))$('imgPrevRL').onclick=function(){imgDoRot(270)};
 if($('imgPrevRR'))$('imgPrevRR').onclick=function(){imgDoRot(90)};
 if($('imgPrevEd'))$('imgPrevEd').onclick=function(){if(!file)return;edOpen(file,async function(bl){var nf=new File([bl],(file.name||'image').replace(/\.[^.]+$/,'')+'.jpg',{type:'image/jpeg'});file=nf;if(tu)URL.revokeObjectURL(tu);tu=URL.createObjectURL(nf);$('timg').src=tu},{filter:'orig'})};
 $('sel').onclick=function(){inp.click()};
 drop.onclick=function(){inp.click()};
 drop.onkeydown=function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();inp.click()}};
 inp.onchange=function(){var fl=Array.prototype.slice.call(inp.files);if(fl.length>1)setBatch(fl);else pick(fl[0])};
 $('clr').onclick=function(){GAL.clear()};$('tx').onclick=function(){GAL.clear()};
 ['dragover','dragenter'].forEach(function(v){drop.addEventListener(v,function(e){e.preventDefault();drop.classList.add('on')})});
 ['dragleave','drop'].forEach(function(v){drop.addEventListener(v,function(e){e.preventDefault();drop.classList.remove('on')})});
 drop.addEventListener('drop',function(e){var fl=Array.prototype.slice.call(e.dataTransfer.files);if(fl.length>1)setBatch(fl);else pick(fl[0])});

 var kb=$('kb');
 Q('[data-kb]').forEach(function(c){c.onclick=function(){Q('[data-kb]').forEach(function(x){x.setAttribute('aria-pressed',x===c)});kb.value=c.dataset.kb}});
 kb.oninput=function(){Q('[data-kb]').forEach(function(x){x.setAttribute('aria-pressed',x.dataset.kb===kb.value)})};
 Q('[data-fmt]').forEach(function(c){c.onclick=function(){fmt=c.dataset.fmt;Q('[data-fmt]').forEach(function(x){x.setAttribute('aria-pressed',x===c)})}});
 $('rw').oninput=function(){if($('lock').checked&&this.value)$('rh').value=Math.round(this.value/ratio)};
 $('rh').oninput=function(){if($('lock').checked&&this.value)$('rw').value=Math.round(this.value*ratio)};
 Q('[data-w]').forEach(function(c){c.onclick=function(){Q('[data-w]').forEach(function(x){x.setAttribute('aria-pressed',x===c?'true':'false')});$('lock').checked=false;$('rw').value=c.dataset.w;$('rh').value=c.dataset.h;updateResizeOverlay()}});
 // Resize crop overlay is attached to the actual large gallery preview (galImg), not the hidden legacy preview.
 var resizeOverlay=$('resizeCropOverlay'),resizeLabel=$('resizeFrameLabel'),resizeDrag=null,resizeMode='fit';
 var resizeOriginalParent=resizeOverlay.parentNode;
 function resizePanelActive(){var p=document.querySelector('[data-panel="images"] [data-subpanel="resize"]');return !!(p&&!p.hidden)}
 function resizePreview(){var gi=$('galImg'),gal=$('gal');if(gal&&!gal.hidden&&gi&&gi.getBoundingClientRect().width)return {im:gi,stage:$('gal-wrap')||gi.parentElement,kind:'gallery'};return {im:$('timg'),stage:$('imgPrevStage'),kind:'legacy'};}
 function resizeActive(){return resizePanelActive()&&!!(file&&img)&&!!(resizePreview().im&&resizePreview().im.getBoundingClientRect().width)}
 function updateResizeOverlay(){
  if(!resizeOverlay)return;
  var panelActive=resizePanelActive(),active=resizeActive(),mc=$('resizeModeControls'),sp=$('resizeSizePresets'),act=$('resizeActionUnderPreview');if(mc)mc.hidden=!panelActive;if(sp)sp.hidden=!panelActive;if(act)act.hidden=!panelActive;
  var guide=$('resizeGuide');if(guide)guide.style.display=active&&resizeMode==='crop'?'block':'none';
  var pv=resizePreview(),imEl=pv.im,stage=pv.stage;
  var galleryVisible=!!($('gal')&&!$('gal').hidden&&$('galImg')&&$('galImg').naturalWidth);
  if(pv.kind==='gallery'&&galleryVisible){
   var wrap=$('galImg').parentElement;
   if(resizeMode==='fit'&&panelActive){
    var fw=Math.max(1,parseInt($('rw').value,10)||$('galImg').naturalWidth),fh=Math.max(1,parseInt($('rh').value,10)||$('galImg').naturalHeight);
    var maxW=Math.max(160,(wrap.parentElement.clientWidth||imEl.getBoundingClientRect().width||fw)-8);
    var maxH=Math.max(220,Math.min(window.innerHeight*.62,620));
    var scale=Math.min(maxW/fw,maxH/fh);
    wrap.classList.add('resize-fit-preview');imEl.classList.add('resize-fit-preview-img');
    wrap.style.width=Math.max(1,Math.round(fw*scale))+'px';
    wrap.style.height=Math.max(1,Math.round(fh*scale))+'px';
    wrap.style.aspectRatio=fw+'/'+fh;
    imEl.style.width='100%';imEl.style.height='100%';imEl.style.maxWidth='none';imEl.style.maxHeight='none';imEl.style.objectFit='fill';
   }else{
    wrap.classList.remove('resize-fit-preview');imEl.classList.remove('resize-fit-preview-img');
    wrap.style.width='';wrap.style.height='';wrap.style.aspectRatio='';
    imEl.style.width='';imEl.style.height='';imEl.style.maxWidth='';imEl.style.maxHeight='';imEl.style.objectFit='';
   }
   if(resizeOverlay.parentNode!==wrap)wrap.appendChild(resizeOverlay);stage=wrap;
  }else if(resizeOverlay.parentNode!==resizeOriginalParent){resizeOriginalParent.appendChild(resizeOverlay);stage=$('imgPrevStage');}
  if(($('galCropBar')&&!$('galCropBar').hidden)||!active||resizeMode!=='crop'){resizeOverlay.style.display='none';return;}
  var ir=imEl.getBoundingClientRect(),sr=stage.getBoundingClientRect();
  if(!ir.width||!ir.height){resizeOverlay.style.display='none';return;}
  var w=Math.max(1,parseInt($('rw').value,10)||img.naturalWidth),h=Math.max(1,parseInt($('rh').value,10)||img.naturalHeight),ar=w/h;
  var boxW=Math.min(ir.width*.72,ir.height*.72*ar),boxH=boxW/ar;
  if(boxH>ir.height*.82){boxH=ir.height*.82;boxW=boxH*ar;}if(boxW>ir.width*.88){boxW=ir.width*.88;boxH=boxW/ar;}
  var oldW=parseFloat(resizeOverlay.style.width)||0,oldH=parseFloat(resizeOverlay.style.height)||0,left=parseFloat(resizeOverlay.style.left),top=parseFloat(resizeOverlay.style.top);
  if(!Number.isFinite(left)||!Number.isFinite(top)||!oldW||!oldH){left=ir.left-sr.left+(ir.width-boxW)/2;top=ir.top-sr.top+(ir.height-boxH)/2;}
  else{left=ir.left-sr.left+Math.max(0,Math.min(ir.width-boxW,left-(ir.left-sr.left)));top=ir.top-sr.top+Math.max(0,Math.min(ir.height-boxH,top-(ir.top-sr.top)));}
  resizeOverlay.style.width=boxW+'px';resizeOverlay.style.height=boxH+'px';resizeOverlay.style.left=left+'px';resizeOverlay.style.top=top+'px';resizeOverlay.style.display='block';resizeLabel.textContent=w+' × '+h+' px · CROP';
 }
 function resizeMoveStart(e){if(!resizeActive()||resizeMode!=='crop')return;e.preventDefault();resizeDrag={x:e.clientX,y:e.clientY,left:parseFloat(resizeOverlay.style.left)||0,top:parseFloat(resizeOverlay.style.top)||0};if(resizeOverlay.setPointerCapture)resizeOverlay.setPointerCapture(e.pointerId)}
 function resizeMove(e){if(!resizeDrag)return;var pv=resizePreview(),ir=pv.im.getBoundingClientRect(),sr=pv.stage.getBoundingClientRect(),w=resizeOverlay.offsetWidth,h=resizeOverlay.offsetHeight;resizeOverlay.style.left=Math.max(ir.left-sr.left,Math.min(ir.right-sr.left-w,resizeDrag.left+e.clientX-resizeDrag.x))+'px';resizeOverlay.style.top=Math.max(ir.top-sr.top,Math.min(ir.bottom-sr.top-h,resizeDrag.top+e.clientY-resizeDrag.y))+'px'}
 if(resizeOverlay){resizeOverlay.addEventListener('pointerdown',resizeMoveStart);window.addEventListener('pointermove',resizeMove);window.addEventListener('pointerup',function(){resizeDrag=null});window.addEventListener('resize',updateResizeOverlay)}
 $('rw').addEventListener('input',updateResizeOverlay);$('rh').addEventListener('input',updateResizeOverlay);$('lock').addEventListener('change',updateResizeOverlay);
 if($('resizeModeFit'))$('resizeModeFit').addEventListener('click',function(){if($('galCropBar')&&!$('galCropBar').hidden&&window.cropEditorClose)window.cropEditorClose();setResizeMode('fit');});if($('resizeModeCrop'))$('resizeModeCrop').addEventListener('click',function(){setResizeMode('crop');if(window.cropEditorOpen)window.cropEditorOpen();updateResizeOverlay();});
 function setResizeMode(mode){resizeMode=mode;var mc=$('resizeModeControls');if(mc)mc.hidden=!resizePanelActive();var guide=$('resizeGuide');if(guide)guide.style.display=resizeActive()&&mode==='crop'?'block':'none';var fit=$('resizeModeFit'),crop=$('resizeModeCrop');if(fit)fit.setAttribute('aria-pressed',mode==='fit'?'true':'false');if(crop)crop.setAttribute('aria-pressed',mode==='crop'?'true':'false');var help=$('resizeModeHelp');if(help)help.textContent=mode==='fit'?'Fit / Stretch: the whole image fills the selected size.':'Crop: drag the blue box over the area you want to keep; only that part is used.';updateResizeOverlay()}
 var _showSub=showSub;showSub=function(panel,key){_showSub(panel,key);if(panel==='images'){setTimeout(function(){setResizeMode(resizeMode);updateResizeOverlay()},100)}};setResizeMode('fit');

 function blob(c,type,q){return new Promise(function(r){c.toBlob(r,type,q)})}
 function base(){return (file?file.name:'image').replace(/\.[^.]+$/,'')}
 function draw(w,h,white){
  var c=document.createElement('canvas');c.width=w;c.height=h;
  var x=c.getContext('2d');
  x.imageSmoothingEnabled=true;
  x.imageSmoothingQuality='high';
  if(white){x.fillStyle='#fff';x.fillRect(0,0,w,h)}
  x.drawImage(img,0,0,w,h);
  return c;
 }
 function result(b,name,stats){
  if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(b);
  $('prev').src=url;
  var d=$('dl');d.href=url;d.setAttribute('data-et-base-name',name);d.download=easyToolsTimestampFilename(name);d.textContent='Download '+name.split('.').pop().toUpperCase();
  var ld=$('lbDl');if(ld){ld.href=url;ld.setAttribute('data-et-base-name',name);ld.download=easyToolsTimestampFilename(name);ld.textContent='Download '+name.split('.').pop().toUpperCase()}
  $('stats').textContent=stats;msg.textContent='';$('done').classList.add('show');$('done').scrollIntoView({behavior:'smooth',block:'nearest'});
 }

 // Lightbox: tap/click preview to view full size before download
 (function(){
  var lb=$('imageLightbox'), lbImg=$('lbImg'), lbClose=$('lbClose');
  if(!lb||!lbImg)return;
  function openLb(){
    if(!$('prev').src)return;
    lbImg.src=$('prev').src;
    lb.classList.add('show');
    document.body.style.overflow='hidden';
  }
  function closeLb(){
    lb.classList.remove('show');
    document.body.style.overflow='';
  }
  $('prev').addEventListener('click',openLb);
  $('prev').addEventListener('dblclick',function(e){e.preventDefault();openLb()});
  if(lbClose)lbClose.onclick=closeLb;
  lb.addEventListener('click',function(e){if(e.target===lb)closeLb()});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&lb.classList.contains('show'))closeLb()});
 })();
 var EXT={jpeg:'jpg',png:'png',webp:'webp'};

 var mode='size',pct=$('pct');
 function upd(){$('pv').textContent=pct.value;$('est').textContent=file?'→ about '+size(file.size*(1-pct.value/100)):''}
 pct.oninput=function(){Q('[data-pct]').forEach(function(x){x.setAttribute('aria-pressed',x.dataset.pct===pct.value)});upd()};
 Q('[data-pct]').forEach(function(c){c.onclick=function(){pct.value=c.dataset.pct;pct.oninput()}});
 Q('[data-mode]').forEach(function(c){c.onclick=function(){mode=c.dataset.mode;
  Q('[data-mode]').forEach(function(x){x.setAttribute('aria-pressed',x===c)});
  $('bysize').hidden=mode!=='size';$('bypct').hidden=mode!=='pct';upd()}});
 inp.addEventListener('change',function(){setTimeout(upd,300)});

 // High-quality compression using browser-image-compression library
 async function compress(){
  var targetBytes=mode==='pct'?Math.round(file.size*(1-pct.value/100)):Math.round(parseFloat(kb.value)*1024);
  if(!targetBytes||targetBytes<5120)return err('Enter a target of at least 5 KB.');

  if(typeof imageCompression==='undefined'){
    // Fallback to improved canvas method if library failed to load
    return compressFallback(targetBytes);
  }

  try{
    var maxSizeMB=targetBytes/1048576;
    // Prefer WebP for much better quality at small sizes
    var preferWebP=(window.__outfmt==='webp');
    var options={
      maxSizeMB:maxSizeMB,
      maxWidthOrHeight:Math.max(img.naturalWidth,img.naturalHeight),
      useWebWorker:true,
      initialQuality:0.92,
      alwaysKeepResolution:false,
      fileType:preferWebP?'image/webp':'image/jpeg'
    };

    var compressed=await imageCompression(file,options);

    // If still larger than target, try again with stricter settings
    if(compressed.size>targetBytes*1.08){
      options.maxSizeMB=maxSizeMB*0.92;
      options.initialQuality=0.85;
      options.maxWidthOrHeight=Math.round(Math.max(img.naturalWidth,img.naturalHeight)*0.92);
      compressed=await imageCompression(file,options);
    }

    // If WebP result is still too big or browser doesn't support well, try JPEG
    if(compressed.size>targetBytes*1.15 && preferWebP){
      options.fileType='image/jpeg';
      options.maxSizeMB=maxSizeMB;
      options.initialQuality=0.88;
      compressed=await imageCompression(file,options);
    }

    var ext=compressed.type==='image/webp'?'webp':'jpg';
    var w=0,h=0;
    try{
      var bmp=await createImageBitmap(compressed);
      w=bmp.width;h=bmp.height;bmp.close();
    }catch(e){}

    result(compressed,base()+'-compressed.'+ext,
      size(file.size)+' → '+size(compressed.size)+(w?' · '+w+'×'+h+' px':'')+' · high quality');
  }catch(e){
    console.warn('Library compression failed, using fallback',e);
    return compressFallback(targetBytes);
  }
 }

 // Improved canvas fallback (better than original)
 async function compressFallback(targetBytes){
  var w=img.naturalWidth,h=img.naturalHeight,scale=1,best=null,c,bestType='image/jpeg';
  var tryWebP=(window.__outfmt==='webp');
  for(var n=0;n<16&&!best;n++){
    var cw=Math.max(1,Math.round(w*scale)),ch=Math.max(1,Math.round(h*scale));
    c=draw(cw,ch,true);
    var types=tryWebP?['image/webp','image/jpeg']:['image/jpeg'];
    for(var ti=0;ti<types.length;ti++){
      var type=types[ti];
      var lo=0.08,hi=0.95,b=await blob(c,type,lo);
      if(!b||b.size>targetBytes){continue}
      best=b;bestType=type;
      for(var k=0;k<8;k++){
        var m=(lo+hi)/2,t=await blob(c,type,m);
        if(t&&t.size<=targetBytes){best=t;lo=m}else hi=m;
      }
      if(best)break;
    }
    if(best)break;
    scale*=0.82;
  }
  if(!best)return err('This target is too small for this image. Try a larger size.');
  var ext=bestType==='image/webp'?'webp':'jpg';
  result(best,base()+'-compressed.'+ext,size(file.size)+' → '+size(best.size)+' · '+c.width+'×'+c.height+' px');
 }

 async function convert(){
  var type='image/'+fmt;
  // Prefer library for better quality when converting to lossy formats
  if((fmt==='jpeg'||fmt==='webp') && typeof imageCompression!=='undefined'){
    try{
      var options={
        maxSizeMB:50,
        maxWidthOrHeight:Math.max(img.naturalWidth,img.naturalHeight),
        useWebWorker:true,
        initialQuality:0.92,
        alwaysKeepResolution:true,
        fileType:type
      };
      var out=await imageCompression(file,options);
      if(out&&out.type===type){
        result(out,base()+'.'+EXT[fmt],file.type.replace('image/','').toUpperCase()+' → '+fmt.toUpperCase()+' · '+size(out.size));
        return;
      }
    }catch(e){}
  }
  // Canvas fallback with high quality
  var c=draw(img.naturalWidth,img.naturalHeight,fmt==='jpeg');
  var b=await blob(c,type,fmt==='png'?undefined:0.92);
  if(!b||(fmt!=='png'&&b.type!==type))return err('Your browser cannot create this format. Try JPG or PNG.');
  result(b,base()+'.'+EXT[fmt],file.type.replace('image/','').toUpperCase()+' → '+fmt.toUpperCase()+' · '+size(b.size));
 }

 async function resize(){
  var w=Math.round($('rw').value),h=Math.round($('rh').value);
  if(!(w>=1&&h>=1&&w<=8000&&h<=8000))return err('Enter a width and height between 1 and 8000 px.');
  var preferType=/^image\/(jpeg|png|webp)$/.test(file.type)?file.type:'image/png';
  var f=preferType.slice(6);

  if(resizeMode==='crop'){
   var ov=$('resizeCropOverlay'),pv=resizePreview(),imEl=pv.im;
   if(!ov||ov.style.display==='none'||!imEl||!imEl.naturalWidth)return err('Select an image, choose Crop, and position the blue crop box first.');
   var ir=imEl.getBoundingClientRect(),or=ov.getBoundingClientRect();
   var sx=Math.max(0,(or.left-ir.left)/ir.width*img.naturalWidth),sy=Math.max(0,(or.top-ir.top)/ir.height*img.naturalHeight);
   var sw=Math.min(img.naturalWidth-sx,or.width/ir.width*img.naturalWidth),sh=Math.min(img.naturalHeight-sy,or.height/ir.height*img.naturalHeight);
   if(sw<1||sh<1)return err('Move the crop box inside the image.');
   var cropCanvas=document.createElement('canvas');cropCanvas.width=w;cropCanvas.height=h;var cropCtx=cropCanvas.getContext('2d');cropCtx.imageSmoothingEnabled=true;cropCtx.imageSmoothingQuality='high';
   if(preferType==='image/jpeg'){cropCtx.fillStyle='#fff';cropCtx.fillRect(0,0,w,h)}
   cropCtx.drawImage(img,sx,sy,sw,sh,0,0,w,h);
   var cropBlob=await blob(cropCanvas,preferType,preferType==='image/png'?undefined:0.92);
   result(cropBlob,base()+'-'+w+'x'+h+'-crop.'+EXT[f],Math.round(sw)+'×'+Math.round(sh)+' crop → '+w+'×'+h+' px · '+size(cropBlob.size));return;
  }


  // Use library when downscaling for better quality
  if(typeof imageCompression!=='undefined' && (w<img.naturalWidth||h<img.naturalHeight)){
    try{
      var options={
        maxSizeMB:40,
        maxWidthOrHeight:Math.max(w,h),
        useWebWorker:true,
        initialQuality:0.92,
        alwaysKeepResolution:false,
        fileType:preferType
      };
      var out=await imageCompression(file,options);
      // Final exact resize with high-quality canvas
      var tmp=new Image();
      var u=URL.createObjectURL(out);
      await new Promise(function(res,rej){tmp.onload=res;tmp.onerror=rej;tmp.src=u});
      var c=document.createElement('canvas');c.width=w;c.height=h;
      var x=c.getContext('2d');
      x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';
      if(f==='jpeg'){x.fillStyle='#fff';x.fillRect(0,0,w,h)}
      x.drawImage(tmp,0,0,w,h);
      URL.revokeObjectURL(u);
      var b=await blob(c,preferType,f==='png'?undefined:0.92);
      result(b,base()+'-'+w+'x'+h+'.'+EXT[f],img.naturalWidth+'×'+img.naturalHeight+' → '+w+'×'+h+' px · '+size(b.size));
      return;
    }catch(e){}
  }

  // Pure canvas high-quality path
  var c=draw(w,h,f==='jpeg');
  var b=await blob(c,preferType,f==='png'?undefined:0.92);
  result(b,base()+'-'+w+'x'+h+'.'+EXT[f],img.naturalWidth+'×'+img.naturalHeight+' → '+w+'×'+h+' px · '+size(b.size));
 }
 async function qr(text,label){
  if(!text.trim())return err('Please enter some text first.');
  if(typeof qrcode==='undefined')return err('The QR library did not load. Check your internet and reload.');
  try{
   if(qrcode.stringToBytesFuncs&&qrcode.stringToBytesFuncs['UTF-8'])qrcode.stringToBytes=qrcode.stringToBytesFuncs['UTF-8'];
   var q=qrcode(0,'M');q.addData(text.trim());q.make();
   var n=q.getModuleCount(),s=Math.max(3,Math.floor(560/(n+8))),c=document.createElement('canvas');
   c.width=c.height=(n+8)*s;var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.fillStyle='#000';
   for(var r=0;r<n;r++)for(var k=0;k<n;k++)if(q.isDark(r,k))x.fillRect((k+4)*s,(r+4)*s,s,s);
   result(await blob(c,'image/png'),'qr-code.png',label+' · '+c.width+'×'+c.height+' px');
  }catch(e){err('This text is too long for a QR code. Please shorten it.')}
 }
 $('qrtext').oninput=function(){$('qcount').textContent=this.value.length};
  var run={compress:compress,convert:convert,resize:resize,
  qr:function(){return qr($('qrtext').value,'QR code ready')},
  url:function(){var v=$('urltext').value.trim();if(v&&!/^[a-z][a-z0-9+.-]*:/i.test(v))v='https://'+v;return qr(v,'QR code for '+v)}};
 function bindQrDecode(){
  var qrf=null;
  function set(f){
    qrf=f;
    $('qrrun').disabled=!f;
    $('qrdrop').innerHTML=f?(f.name+' · '+size(f.size)):'Choose or drop a QR-code image<br><small>QR is decoded locally in your browser</small>';
    $('qrresult').value='';
    $('qrcopy').disabled=true;
  }
  bindFile('qrfile','qrdrop','qrclear',function(f){return f&&f.type.indexOf('image/')===0},set);
  $('qrs').onclick=function(){$('qrfile').click()};
  $('qrrun').onclick=function(){
    if(!qrf)return;
    if(typeof jsQR==='undefined')return err('QR decoder library did not load. Check internet and reload.');
    msg.textContent='Decoding…';
    var im=new Image(),u=URL.createObjectURL(qrf);
    im.onload=function(){
      try{
        var w=im.naturalWidth,h=im.naturalHeight,maxDim=1200,scale=1;
        if(Math.max(w,h)>maxDim){scale=maxDim/Math.max(w,h);w=Math.round(w*scale);h=Math.round(h*scale);}
        var c=document.createElement('canvas');c.width=w;c.height=h;
        var x=c.getContext('2d');x.imageSmoothingEnabled=false;x.drawImage(im,0,0,w,h);
        var d=x.getImageData(0,0,w,h);
        var code=jsQR(d.data,w,h,{inversionAttempts:"dontInvert"});
        if(!code)code=jsQR(d.data,w,h,{inversionAttempts:"onlyInvert"});
        if(!code)code=jsQR(d.data,w,h,{inversionAttempts:"attemptBoth"});
        URL.revokeObjectURL(u);
        if(!code)return err('No readable QR code was found. Try a clearer or higher-contrast image.');
        $('qrresult').value=code.data;$('qrcopy').disabled=false;msg.textContent='QR decoded successfully.';
      }catch(e){URL.revokeObjectURL(u);err('Could not decode this image.');}
    };
    im.onerror=function(){URL.revokeObjectURL(u);err('The image could not be read.');};
    im.src=u;
  };
  $('qrcopy').onclick=async function(){
    try{await navigator.clipboard.writeText($('qrresult').value);msg.textContent='Text copied.';}
    catch(e){$('qrresult').select();document.execCommand('copy');msg.textContent='Text copied.';}
  };
}
bindQrDecode();

Q('[data-run]').forEach(function(b){b.onclick=async function(){
  var t=b.dataset.run;b.disabled=true;msg.textContent='Working…';$('done').classList.remove('show');
  try{await run[t]()}catch(e){err('Something went wrong. Please try another file.')}
  if(t==='qr'||t==='url'||img)b.disabled=false;
 }});

 // Browser-only document tools
 function bindFile(selectId,dropId,clearId,acceptFn,cb){
  var inp=$(selectId),drop=$(dropId),clear=$(clearId); if(!inp||!drop)return;
  $(selectId.replace('file','s'));
  function set(f){if(!f)return;if(acceptFn&&!acceptFn(f)){err('Please choose a supported file.');return}cb(f)}
  drop.onclick=function(){inp.click()}; inp.onchange=function(){set(inp.files[0])};
  ['dragover','dragenter'].forEach(function(v){drop.addEventListener(v,function(e){e.preventDefault();drop.classList.add('on')})});
  ['dragleave','drop'].forEach(function(v){drop.addEventListener(v,function(e){e.preventDefault();drop.classList.remove('on')})});
  drop.addEventListener('drop',function(e){set(e.dataTransfer.files[0])}); if(clear)clear.onclick=function(){inp.value='';drop.classList.remove('on');cb(null)};
 }
 function downloadBlob(b,name,stats){result(b,name,stats)}
 function pdfApi(){return window.PDFLib}
 var pdfE=null,ecFile=null,epFile=null,ecMode='csv';
 var pdfMode='light';
 function pdfOk(f){return f&&f.type==='application/pdf'}

 /* ---------------- Shared PDF selection ----------------
    Single source of truth for Compress, Merge, Split, PDF to Image and Edit PDF.
    PDFShared.files holds the ORIGINAL selected PDFs in order. Each tool reads from it when it runs.
    Edit PDF keeps a separate, clearly labelled WORKING copy (EP) of PDFShared.files[0]; it is never
    discarded without asking. Image to PDF / Scan Document use the same gallery shell for image previews, while keeping their own image-processing state. */
 var PS=window.PDFShared={
  files:[],tool:'pdfcompress',cache:new Map(),subs:[],edit:null,
  first:function(){return PS.files[0]||null},
  on:function(fn){PS.subs.push(fn)},
  emit:function(kind,origin){PS.subs.slice().forEach(function(fn){try{fn(kind,origin)}catch(e){console.error(e)}})},
  isPdf:function(f){return !!f&&(f.type==='application/pdf'||/\.pdf$/i.test(f.name||''))},
  same:function(list){return list.length===PS.files.length&&list.every(function(f,i){return f===PS.files[i]})},
  confirmDiscard:function(action){
   if(!PS.edit||!PS.edit.isDirty())return true;
   return window.confirm('Edit PDF has unsaved page changes (rotated, deleted, reordered, edited or added pages). '+action+' will discard them. Continue?')},
  resetInputs:function(){['pdfcfile','pdfsfile','pdfmfiles','pdfifile'].forEach(function(id){var el=$(id);if(el)el.value=''})},
  prune:function(){PS.cache.forEach(function(v,k){if(PS.files.indexOf(k)<0)PS.cache.delete(k)})},
  setFiles:function(list,origin){
   list=Array.prototype.slice.call(list||[]).filter(PS.isPdf);
   if(!list.length)return false;
   if(PS.same(list))return true;
   if(!PS.confirmDiscard('Selecting another PDF')){PS.resetInputs();return false}
   if(PS.edit)PS.edit.reset();
   PS.files=list;PS.prune();PS.emit('select',origin);return true},
  clear:function(origin,force){
   if(!force&&!PS.confirmDiscard('Clearing the PDF'))return false;
   PS.files=[];PS.cache.clear();if(PS.edit)PS.edit.reset();msg.textContent='';PS.emit('clear',origin);return true},
  move:function(i,d){
   var j=i+d;if(i<0||j<0||i>=PS.files.length||j>=PS.files.length)return false;
   var next=PS.files.slice();next.splice(j,0,next.splice(i,1)[0]);
   if(next[0]!==PS.files[0]){if(!PS.confirmDiscard('Putting a different PDF first'))return false;if(PS.edit)PS.edit.reset()}
   PS.files=next;PS.emit('order');return true},
  /* parsed pdf.js document, cached per File so switching tools never re-reads the file */
  load:function(file){
   var c=PS.cache.get(file);if(!c){c={pages:{}};PS.cache.set(file,c)}
   if(!c.doc){c.doc=(async function(){await loadFor('pdf');var bytes=new Uint8Array(await file.arrayBuffer());var doc=await pdfjsLib.getDocument({data:bytes.slice()}).promise;return {doc:doc,bytes:bytes}})();
    c.doc.catch(function(){if(PS.cache.get(file)===c)PS.cache.delete(file)})}
   return c.doc},
  /* page preview (data URL, same size the Edit gallery has always used), cached per File + page */
  renderPage:function(file,n){
   var c=PS.cache.get(file);if(!c){c={pages:{}};PS.cache.set(file,c)}
   if(!c.pages[n]){c.pages[n]=(async function(){var d=await PS.load(file),pg=await d.doc.getPage(n),vp=pg.getViewport({scale:1}),v2=pg.getViewport({scale:Math.min(1.35,1000/Math.max(vp.width,vp.height))}),cv=document.createElement('canvas');cv.width=Math.max(1,Math.round(v2.width));cv.height=Math.max(1,Math.round(v2.height));
     await pg.render({canvasContext:cv.getContext('2d',{alpha:false}),viewport:v2}).promise;return cv.toDataURL('image/jpeg',0.9)})();
    c.pages[n].catch(function(){if(c.pages)delete c.pages[n]})}
   return c.pages[n]}
 };
 /* keep every tool's own drop zone / buttons in step with the one shared selection */
 (function(){
  var defs={};['pdfcdrop','pdfsdrop','pdfidrop'].forEach(function(id){var el=$(id);if(el)defs[id]=el.innerHTML});
  function label(id,f){var el=$(id);if(!el)return;if(f){el.textContent=f.name+' · '+size(f.size)}else el.innerHTML=defs[id]}
  function sync(){
   var f=PS.first(),n=PS.files.length;
   label('pdfcdrop',f);label('pdfsdrop',f);label('pdfidrop',f);
   if($('pdfcrun'))$('pdfcrun').disabled=!f;
   if($('pdfsrun'))$('pdfsrun').disabled=!f;
   if($('pdfirun'))$('pdfirun').disabled=!f;
   if($('pdfmrun'))$('pdfmrun').disabled=n<2;
   if($('pdmlist'))$('pdmlist').textContent=n?n+' PDF file(s): '+PS.files.map(function(x){return x.name}).join(' · '):'';
   if(!n)PS.resetInputs();
  }
  PS.on(sync);
 })();

 // PDF compress mode toggle
 Q('[data-pdfmode]').forEach(function(btn){
  btn.onclick=function(){
   pdfMode=btn.dataset.pdfmode;
   Q('[data-pdfmode]').forEach(function(x){x.setAttribute('aria-pressed',x===btn?'true':'false')});
  };
 });

 // Setup pdf.js worker if available
 if(window.pdfjsLib){
  try{pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';}catch(e){}
 }

 bindFile('pdfcfile','pdfcdrop','pdfcc',pdfOk,function(f){if(f)PS.setFiles([f],'pdfcompress');else PS.clear('pdfcompress')});
 $('pdfcs').onclick=function(){$('pdfcfile').click()};

 async function compressPdfLight(file){
  var a=await pdfApi().PDFDocument.load(await file.arrayBuffer(),{ignoreEncryption:true});
  var out=await a.save({useObjectStreams:true,addDefaultPage:false});
  return new Blob([out],{type:'application/pdf'});
 }

 async function compressPdfStrong(file){
  if(!window.pdfjsLib)throw Error('PDF renderer not loaded');
  var data=await file.arrayBuffer();
  var pdf=await pdfjsLib.getDocument({data:data}).promise;
  var newPdf=await pdfApi().PDFDocument.create();
  var scale=1.5; // ~108-150 DPI feel; balance size vs clarity
  var quality=0.72;
  for(var i=1;i<=pdf.numPages;i++){
   msg.textContent='Strong compress… page '+i+' / '+pdf.numPages;
   var page=await pdf.getPage(i);
   var viewport=page.getViewport({scale:scale});
   var canvas=document.createElement('canvas');
   canvas.width=Math.floor(viewport.width);
   canvas.height=Math.floor(viewport.height);
   var ctx=canvas.getContext('2d');
   ctx.fillStyle='#fff';
   ctx.fillRect(0,0,canvas.width,canvas.height);
   await page.render({canvasContext:ctx,viewport:viewport}).promise;
   var jpeg=await new Promise(function(res){canvas.toBlob(res,'image/jpeg',quality)});
   if(!jpeg)throw Error('Could not render page '+i);
   var bytes=new Uint8Array(await jpeg.arrayBuffer());
   var img=await newPdf.embedJpg(bytes);
   var p=newPdf.addPage([img.width,img.height]);
   p.drawImage(img,{x:0,y:0,width:img.width,height:img.height});
  }
  var out=await newPdf.save({useObjectStreams:true});
  return new Blob([out],{type:'application/pdf'});
 }

 $('pdfcrun').onclick=async function(){
  var pdfC=PS.first();
  if(!pdfC)return;
  msg.textContent='Working…';
  try{
   var blob,label;
   if(pdfMode==='strong'){
    blob=await compressPdfStrong(pdfC);
    label='Strong';
   }else{
    blob=await compressPdfLight(pdfC);
    label='Light';
   }
   var pct=Math.round((1-blob.size/pdfC.size)*100);
   var change=blob.size<pdfC.size?(pct+'% smaller'):(blob.size>pdfC.size?'slightly larger':'similar size');
   downloadBlob(blob,pdfC.name.replace(/\.pdf$/i,'')+'-'+label.toLowerCase()+'.pdf',
    size(pdfC.size)+' → '+size(blob.size)+' · '+label+' · '+change);
  }catch(e){
   console.error(e);
   err(pdfMode==='strong'
     ?'Strong compress failed. Try Light mode, or the PDF may be protected.'
     :'This PDF could not be rebuilt. It may be encrypted or malformed.');
  }
 };

 bindFile('pdfmfiles','pdfmdrop','pdfmc',pdfOk,function(f){if(!f)PS.clear('pdfmerge') /* dropped files are handled below; the file input handles many */});
 $('pdfms').onclick=function(){$('pdfmfiles').click()};
 $('pdfmfiles').onchange=function(){PS.setFiles(Array.from(this.files||[]),'pdfmerge')};
 $('pdfmdrop').addEventListener('drop',function(e){var fl=Array.from((e.dataTransfer&&e.dataTransfer.files)||[]).filter(pdfOk);if(fl.length>1)PS.setFiles(fl,'pdfmerge')});
 $('pdfmrun').onclick=async function(){var pdfM=PS.files.slice();if(pdfM.length<2)return;msg.textContent='Working…';try{var out=await pdfApi().PDFDocument.create();for(const f of pdfM){var src=await pdfApi().PDFDocument.load(await f.arrayBuffer());var pages=await out.copyPages(src,src.getPageIndices());pages.forEach(function(p){out.addPage(p)})}var b=await out.save();downloadBlob(new Blob([b],{type:'application/pdf'}),'merged.pdf',pdfM.length+' PDFs → '+size(b.byteLength));}catch(e){err('One of the PDFs could not be merged.')} };

 bindFile('pdfsfile','pdfsdrop','pdfsc',pdfOk,function(f){if(f)PS.setFiles([f],'pdfsplit');else PS.clear('pdfsplit')});
 $('pdfss').onclick=function(){$('pdfsfile').click()};
 function parsePages(spec,max){var set={};spec.split(',').forEach(function(part){part=part.trim();if(!part)return;var a=part.split('-').map(Number);if(a.length===1&&Number.isInteger(a[0]))set[a[0]-1]=1;else if(a.length===2&&Number.isInteger(a[0])&&Number.isInteger(a[1])){var lo=Math.min(a[0],a[1]),hi=Math.max(a[0],a[1]);for(var i=lo;i<=hi;i++)set[i-1]=1}});return Object.keys(set).map(Number).filter(function(i){return i>=0&&i<max}).sort(function(a,b){return a-b})}
 $('pdfsrun').onclick=async function(){var pdfS=PS.first();if(!pdfS)return;msg.textContent='Working…';try{var src=await pdfApi().PDFDocument.load(await pdfS.arrayBuffer()),idx=parsePages($('pagespec').value,src.getPageCount());if(!idx.length)return err('Enter valid pages, for example 1-3, 5, 8.');var out=await pdfApi().PDFDocument.create(),pages=await out.copyPages(src,idx);pages.forEach(function(p){out.addPage(p)});var b=await out.save();downloadBlob(new Blob([b],{type:'application/pdf'}),pdfS.name.replace(/\.pdf$/i,'')+'-pages.pdf',idx.length+' page(s) extracted');}catch(e){err('The PDF could not be split.')} };


 /* PDF to Image: converts the shared selected PDF (all pages) to JPG or PNG */
 (function(){
  var fmt='jpeg',scale=1.5,outUrl2=null;
  bindFile('pdfifile','pdfidrop','pdfic',pdfOk,function(f){if(f)PS.setFiles([f],'pdfimg');else PS.clear('pdfimg')});
  $('pdfis').onclick=function(){$('pdfifile').click()};
  Q('[data-pdfifmt]').forEach(function(b){b.onclick=function(){fmt=b.dataset.pdfifmt;Q('[data-pdfifmt]').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')})}});
  Q('[data-pdfiscale]').forEach(function(b){b.onclick=function(){scale=parseFloat(b.dataset.pdfiscale)||1.5;Q('[data-pdfiscale]').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')})}});
  PS.on(function(kind){if(kind==='select'||kind==='clear'){var o=$('pdfiout');if(o){o.classList.remove('show');o.innerHTML=''}}});
  $('pdfirun').onclick=async function(){
   var f=PS.first();if(!f)return;var bt=this;bt.disabled=true;msg.textContent='Working…';
   try{
    var d=await PS.load(f),n=d.doc.numPages,ext=fmt==='png'?'png':'jpg',mime=fmt==='png'?'image/png':'image/jpeg',base=f.name.replace(/\.pdf$/i,''),blobs=[];
    for(var p=1;p<=n;p++){
     msg.textContent='Converting page '+p+' of '+n+'…';
     var pg=await d.doc.getPage(p),vp0=pg.getViewport({scale:1}),sc=Math.min(scale,4000/Math.max(vp0.width,vp0.height)),vp=pg.getViewport({scale:sc}),cv=document.createElement('canvas');
     cv.width=Math.max(1,Math.round(vp.width));cv.height=Math.max(1,Math.round(vp.height));
     var cx=cv.getContext('2d',{alpha:false});cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height);
     await pg.render({canvasContext:cx,viewport:vp}).promise;
     blobs.push(await new Promise(function(res){cv.toBlob(res,mime,0.92)}));
    }
    var out=$('pdfiout'),blob,name;
    if(outUrl2)URL.revokeObjectURL(outUrl2);
    if(n===1){blob=blobs[0];name=base+'-page-1.'+ext}
    else{await lj('jszip');var zip=new JSZip(),pad=String(n).length;blobs.forEach(function(b,i){zip.file(base+'-page-'+String(i+1).padStart(pad,'0')+'.'+ext,b)});blob=await zip.generateAsync({type:'blob'});name=base+'-images.zip'}
    outUrl2=URL.createObjectURL(blob);
    out.innerHTML='';
    var ok=document.createElement('div');ok.className='ok';ok.textContent='✓ Done! Your '+(n===1?'image is':'images are')+' ready';
    var st=document.createElement('div');st.className='sub';st.textContent=size(blob.size)+' · '+n+' page'+(n>1?'s':'')+' · '+ext.toUpperCase();
    var p2=document.createElement('p');p2.style.margin='14px 0';var a=document.createElement('a');a.className='btn dl';a.href=outUrl2;a.download=easyToolsTimestampFilename(name);a.setAttribute('data-et-base-name',name);a.textContent=n===1?'Download image':'Download ZIP';p2.appendChild(a);
    out.appendChild(ok);out.appendChild(st);out.appendChild(p2);
    out.classList.add('show');msg.textContent='';out.scrollIntoView({behavior:'smooth',block:'nearest'});
   }catch(e){err(e&&e.name==='PasswordException'?'This PDF is password protected.':'The PDF could not be converted to images.')}
   bt.disabled=!PS.first()};
 })();

  function excelOk(f){return f&&(/\.(xlsx|xls|csv)$/i.test(f.name)||/csv|spreadsheet|excel/.test(f.type))}
 function setEc(f){ecFile=f;$('ecrun').disabled=!f;$('fileActions').hidden=!f;$('toCsv').style.display='none';$('toXlsx').style.display='none';$('toPdf').style.display=f?'inline-flex':'none';$('ecdrop').innerHTML=f?(f.name+' · '+size(f.size)):'Choose or drop an Excel or CSV file<br><small>Options will appear according to the file you select</small>';if(f){if(/\.csv$/i.test(f.name)){$('filetype').textContent='CSV file selected — available: Convert to Excel or PDF';$('toXlsx').style.display='inline-flex';}else{$('filetype').textContent='Excel file selected — available: Convert to CSV or PDF';$('toCsv').style.display='inline-flex';}}else $('filetype').textContent='';}
bindFile('ecfile','ecdrop','ecclear',excelOk,setEc);$('ecsel').onclick=function(){$('ecfile').click()};
var ecMode='pdf';
$('toCsv').onclick=function(){ecMode='csv';$('toCsv').setAttribute('aria-pressed','true');$('toXlsx').setAttribute('aria-pressed','false');$('toPdf').setAttribute('aria-pressed','false');$('ecrun').disabled=!ecFile};
$('toXlsx').onclick=function(){ecMode='xlsx';$('toCsv').setAttribute('aria-pressed','false');$('toXlsx').setAttribute('aria-pressed','true');$('toPdf').setAttribute('aria-pressed','false');$('ecrun').disabled=!ecFile};
$('toPdf').onclick=function(){ecMode='pdf';$('toCsv').setAttribute('aria-pressed','false');$('toXlsx').setAttribute('aria-pressed','false');$('toPdf').setAttribute('aria-pressed','true');$('ecrun').disabled=!ecFile};
$('ecrun').onclick=async function(){if(!ecFile)return;msg.textContent='Working…';try{var data=await ecFile.arrayBuffer(),wb;if(/\.csv$/i.test(ecFile.name)){var text=new TextDecoder().decode(data);wb=XLSX.read(text,{type:'string'});}else wb=XLSX.read(data,{type:'array'});var baseName=ecFile.name.replace(/\.(xlsx|xls|csv)$/i,'');if(ecMode==='csv'){var ws=wb.Sheets[wb.SheetNames[0]],csv=XLSX.utils.sheet_to_csv(ws);downloadBlob(new Blob([csv],{type:'text/csv;charset=utf-8'}),baseName+'.csv','First sheet exported to CSV');}else if(ecMode==='xlsx'){var out=XLSX.write(wb,{bookType:'xlsx',type:'array'});downloadBlob(new Blob([out],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),baseName+'.xlsx','Workbook converted to Excel');}else{var jsp=window.jspdf&&window.jspdf.jsPDF;if(!jsp)throw Error('PDF library unavailable');var doc=new jsp({orientation:'landscape',unit:'pt',format:'a4'});wb.SheetNames.forEach(function(name,si){if(si)doc.addPage();var rows=XLSX.utils.sheet_to_json(wb.Sheets[name],{header:1,defval:''});var head=rows.length?rows[0]:[],body=rows.length>1?rows.slice(1):[];doc.text(name,30,28);if(doc.autoTable)doc.autoTable({head:[head],body:body,startY:40,margin:{left:25,right:25},styles:{fontSize:7,cellPadding:3}});else{body.slice(0,45).forEach(function(r,i){doc.text(r.map(String).join(' | ').slice(0,150),30,55+i*12)})}});var b=doc.output('blob');downloadBlob(b,baseName+'.pdf','Spreadsheet converted to PDF');}}catch(e){err('This Excel/CSV file could not be converted.')}};

 // Hide image upload area on non-image tools and update page copy.


 window.__outfmt='jpeg';
 Q('[data-outfmt]').forEach(function(c){c.onclick=function(){window.__outfmt=c.dataset.outfmt;Q('[data-outfmt]').forEach(function(x){x.setAttribute('aria-pressed',x===c?'true':'false')})}});
 if(D.kb){$('kb').value=D.kb;Q('[data-kb]').forEach(function(x){x.setAttribute('aria-pressed',x.dataset.kb===D.kb?'true':'false')})}
 if(D.fmt){fmt=D.fmt;Q('[data-fmt]').forEach(function(x){x.setAttribute('aria-pressed',x.dataset.fmt===D.fmt?'true':'false')})}
 if(D.w){$('rw').value=D.w;$('rh').value=D.h;$('lock').checked=false}

 (function(){
  var vid=$('camvid'),wrap=$('camwrap'),stream=null,raf=0,last=0,cv=document.createElement('canvas'),cx=cv.getContext('2d',{willReadFrequently:true});
  function stop(){cancelAnimationFrame(raf);if(stream){stream.getTracks().forEach(function(t){t.stop()});stream=null}vid.srcObject=null;wrap.hidden=true;$('qrcam').hidden=false}
  function found(text){stop();$('qrresult').value=text;$('qrcopy').disabled=false;msg.textContent='QR code found.'}
  function tick(ts){
   if(!stream)return;
   if(ts-last>120&&vid.readyState>=2&&vid.videoWidth){last=ts;
    var w=Math.min(640,vid.videoWidth),h=Math.round(vid.videoHeight*w/vid.videoWidth);cv.width=w;cv.height=h;cx.drawImage(vid,0,0,w,h);
    var d=cx.getImageData(0,0,w,h),c=window.jsQR&&jsQR(d.data,w,h,{inversionAttempts:'dontInvert'});
    if(c&&c.data)return found(c.data)}
   raf=requestAnimationFrame(tick)}
  $('qrcam').onclick=async function(){
   if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return err('Camera is not available in this browser. Try Chrome or Safari, or choose an image instead.');
   try{await loadFor('qrtools')}catch(e){return err('Could not load the QR decoder. Check your internet and try again.')}
   try{stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});
    vid.srcObject=stream;await vid.play();wrap.hidden=false;$('qrcam').hidden=true;$('qrresult').value='';$('qrcopy').disabled=true;msg.textContent='Point the camera at a QR code.';raf=requestAnimationFrame(tick)}
   catch(e){stream=null;err(e&&e.name==='NotAllowedError'?'Camera permission was denied. Allow camera access in your browser settings, or choose an image instead.':'Could not start the camera. Choose an image instead.')}};
  $('camstop').onclick=function(){stop();msg.textContent=''};
  Q('.tab,.subtab').forEach(function(x){x.addEventListener('click',stop)});
  window.addEventListener('pagehide',stop);
 })();

 // ===== Live camera: photos stay in browser memory, not in the phone gallery =====
 var Cam=(function(){
  var m=$('cm'),v=$('cmvid'),strip=$('cmstrip'),bSnap=$('cmsnap'),bDone=$('cmdone'),bX=$('cmcancel'),bFlip=$('cmflip'),ttl=$('cmtitle'),
   st=null,shots=[],urls=[],cb=null,max=30,facing='environment',n=0;
  function stop(){if(st){st.getTracks().forEach(function(t){t.stop()});st=null}v.srcObject=null}
  function close(){stop();m.hidden=true;document.body.style.overflow='';urls.forEach(function(u){URL.revokeObjectURL(u)});urls=[];shots=[];strip.innerHTML=''}
  function upd(){bDone.disabled=!shots.length;bDone.textContent=shots.length?'Done ('+shots.length+')':'Done';bSnap.disabled=shots.length>=max}
  async function start(){
   stop();
   try{
    st=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:facing},width:{ideal:1920},height:{ideal:1080}},audio:false});
    v.srcObject=st;v.classList.toggle('mirror',facing==='user');await v.play();return true
   }catch(e){stop();return e}
  }
  function nativeFallback(o){
   var i=document.createElement('input');i.type='file';i.accept='image/*';i.setAttribute('capture','environment');i.hidden=true;
   i.onchange=function(){var f=this.files&&this.files[0];i.remove();if(f)o.onDone([f])};
   document.body.appendChild(i);i.click();
  }
  async function open(o){
   if(o.max<=0)return err('You have reached the photo limit.');
   if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return nativeFallback(o);
   max=o.max||30;cb=o.onDone;shots=[];ttl.textContent=o.title||'Camera';
   m.hidden=false;document.body.style.overflow='hidden';upd();msg.textContent='';
   var r=await start();
   if(r!==true){close();err(r&&r.name==='NotAllowedError'?'Camera permission was denied. Allow camera access in your browser settings, or choose photos from your gallery instead.':'Could not start the camera. Choose photos from your gallery instead.')}
  }
  bSnap.onclick=function(){
   if(!st||!v.videoWidth||shots.length>=max)return;
   var w=v.videoWidth,h=v.videoHeight,s=Math.min(1,3000/Math.max(w,h)),cw=Math.round(w*s),ch=Math.round(h*s),c=document.createElement('canvas');
   c.width=cw;c.height=ch;c.getContext('2d').drawImage(v,0,0,cw,ch);
   m.classList.add('flash');setTimeout(function(){m.classList.remove('flash')},130);
   if(navigator.vibrate){try{navigator.vibrate(15)}catch(e){}}
   c.toBlob(function(bl){
    if(!bl)return;
    n++;var f=new File([bl],'camera-photo-'+n+'.jpg',{type:'image/jpeg'}),u=URL.createObjectURL(bl);
    shots.push(f);urls.push(u);
    var th=document.createElement('span');th.className='cm-th';
    th.innerHTML='<img alt="Captured photo" src="'+u+'"><button type="button" aria-label="Remove this photo">✕</button>';
    th.querySelector('button').onclick=function(){var k=shots.indexOf(f);if(k>-1)shots.splice(k,1);th.remove();URL.revokeObjectURL(u);upd()};
    strip.appendChild(th);strip.scrollLeft=strip.scrollWidth;upd();
   },'image/jpeg',0.92)};
  bFlip.onclick=async function(){facing=facing==='environment'?'user':'environment';var r=await start();if(r!==true){facing=facing==='environment'?'user':'environment';await start()}};
  bDone.onclick=function(){var l=shots.slice(),f=cb;close();if(f&&l.length)f(l)};
  bX.onclick=close;
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!m.hidden)close()});
  window.addEventListener('pagehide',close);
  return{open:open};
 })();
 $('camshot').onclick=function(){Cam.open({max:30,title:'Take photos to compress',onDone:function(l){if(l.length===1)pick(l[0]);else setBatch(l)}})};

 // ===== Images to PDF =====
 (function(){
  var items=[],uid=0,mode='one',psize='a4',qual='std',outUrls=[],MAXP=50,ipSel=0;
  var list=$('iplist'),run=$('iprun'),out=$('ipout'),drop=$('ipdrop'),inp=$('ipfile');
  var NOTES={one:'All photos go into one PDF, one photo per page, in the order shown.',long:'All photos are joined top to bottom on a single long page.',sep:'Each photo becomes its own PDF. Download them one by one or all together as a ZIP.'};
  var canShare=false;
  try{canShare=!!(navigator.canShare&&navigator.canShare({files:[new File([new Blob(['x'])],'a.pdf',{type:'application/pdf'})]}))}catch(e){}
  function resetOut(){outUrls.forEach(function(u){URL.revokeObjectURL(u)});outUrls=[];out.classList.remove('show');out.innerHTML=''}
  async function rotatePhoto(i,deg){
   var it=items[i];if(!it)return;
   try{
    var L=await loadImg(it.f),im=L.i,c=document.createElement('canvas'),a=((deg%360)+360)%360;
    c.width=(a===90||a===270)?im.naturalHeight:im.naturalWidth;c.height=(a===90||a===270)?im.naturalWidth:im.naturalHeight;
    var x=c.getContext('2d');x.translate(c.width/2,c.height/2);x.rotate(a*Math.PI/180);x.drawImage(im,-im.naturalWidth/2,-im.naturalHeight/2);URL.revokeObjectURL(L.u);
    var bl=await new Promise(function(resolve){c.toBlob(resolve,'image/jpeg',0.92)});if(!bl)return;
    it.f=new File([bl],(it.f.name||('photo-'+(i+1)+'.jpg')).replace(/\.[^.]+$/,'')+'-rotated.jpg',{type:'image/jpeg'});it.w=c.width;it.h=c.height;it.th=c.toDataURL('image/jpeg',0.78);ipSel=i;resetOut();render();
   }catch(e){err('Could not rotate this photo. Please try again.')}
  }
  function render(){
   list.innerHTML='';list.hidden=!items.length;run.disabled=!items.length;
   if(ipSel>=items.length)ipSel=Math.max(0,items.length-1);
   items.forEach(function(it,i){
    var d=document.createElement('div');d.className='ip-item';
    d.innerHTML='<img alt="Photo '+(i+1)+'" src="'+it.th+'"><span class="ip-n">'+(i+1)+'</span><div class="ip-b"><button type="button" data-a="l" aria-label="Move earlier"'+(i===0?' disabled':'')+'>◀</button><button type="button" data-a="r" aria-label="Move later"'+(i===items.length-1?' disabled':'')+'>▶</button><button type="button" data-a="x" aria-label="Remove photo">✕</button></div>';
    d.querySelectorAll('button').forEach(function(b){b.onclick=function(){
     var k=items.indexOf(it),a=b.dataset.a;
     if(a==='x'){items.splice(k,1);if(ipSel>=items.length)ipSel=Math.max(0,items.length-1);else if(ipSel>k)ipSel--}
     else if(a==='l'&&k>0){items.splice(k,1);items.splice(k-1,0,it);ipSel=k-1}
     else if(a==='r'&&k<items.length-1){items.splice(k,1);items.splice(k+1,0,it);ipSel=k+1}
     resetOut();render()}});
    list.appendChild(d)});
   $('ipcount').textContent=items.length?items.length+' photo'+(items.length>1?'s':'')+' ready':'';
   document.dispatchEvent(new CustomEvent('lovepdfi:image-gallery-update',{detail:{mode:'imgpdf',items:items.map(function(it,i){if(!it._psgFile||it._psgFile!==it.f){if(it._psgUrl)URL.revokeObjectURL(it._psgUrl);it._psgFile=it.f;it._psgUrl=URL.createObjectURL(it.f)}return {src:it._psgUrl,name:it.f.name||('Photo '+(i+1))}}),selected:ipSel,select:function(i){ipSel=i;var el=list.children[i];if(el)el.scrollIntoView({block:'nearest',inline:'nearest'})},action:function(i,a){var el=list.children[i];if(!el&&a!=='rl'&&a!=='rr')return;var map={up:'l',dn:'r',rm:'x'},bt=el&&el.querySelector('button[data-a="'+map[a]+'"]');if(a==='rl'){rotatePhoto(i,270);return}if(a==='rr'){rotatePhoto(i,90);return}if(bt)bt.click()}}}));
  }
  document.addEventListener('lovepdfi:request-image-gallery',function(e){if(!e.detail||e.detail.mode==='imgpdf')render()});
  async function add(files){
   if(files&&files.length){var nr=await normAll(Array.from(files));files=nr.files}
   var l=Array.from(files||[]).filter(function(f){return /^image\//.test(f.type)||/\.(jpe?g|png|webp|gif|bmp|heic|heif)$/i.test(f.name)});
   if(!l.length)return err('Please choose image files (JPG, PNG or WebP).');
   var room=MAXP-items.length;if(room<=0)return err('You can add up to '+MAXP+' photos to one PDF.');
   var cut=l.length>room;l=l.slice(0,room);resetOut();var bad=0;
   for(var k=0;k<l.length;k++){
    msg.textContent='Reading photo '+(k+1)+' of '+l.length+'…';
    try{
     var L=await loadImg(l[k]),im=L.i,w=im.naturalWidth,h=im.naturalHeight,s=Math.min(1,160/Math.max(w,h)),c=document.createElement('canvas');
     c.width=Math.max(1,Math.round(w*s));c.height=Math.max(1,Math.round(h*s));
     var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);
     URL.revokeObjectURL(L.u);
     items.push({id:++uid,f:l[k],w:w,h:h,th:c.toDataURL('image/jpeg',0.7)});
    }catch(e){bad++}
   }
   msg.textContent='';render();
   if(bad||cut){err((bad?bad+' file'+(bad>1?'s':'')+' could not be read. ':'')+(cut?'Only '+MAXP+' photos can be added to one PDF.':''))}
  }
  async function prep(it){
   var L=await loadImg(it.f),im=L.i,w=im.naturalWidth,h=im.naturalHeight,maxS=qual==='small'?1600:2600,s=Math.min(1,maxS/Math.max(w,h)),cw=Math.max(1,Math.round(w*s)),ch=Math.max(1,Math.round(h*s));
   var c=document.createElement('canvas');c.width=cw;c.height=ch;var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,cw,ch);x.drawImage(im,0,0,cw,ch);
   URL.revokeObjectURL(L.u);
   var bl=await new Promise(function(r){c.toBlob(r,'image/jpeg',qual==='small'?0.68:0.88)});
   c.width=c.height=1;
   if(!bl)throw Error('encode');
   return{bytes:new Uint8Array(await bl.arrayBuffer()),w:cw,h:ch};
  }
  function place(pdf,im,w,h){
   var pw,ph,x=0,y=0,dw,dh;
   if(psize==='a4'){var land=w>h;pw=land?841.89:595.28;ph=land?595.28:841.89;var M=18,s=Math.min((pw-2*M)/w,(ph-2*M)/h);dw=w*s;dh=h*s;x=(pw-dw)/2;y=(ph-dh)/2}
   else{var f=841.89/Math.max(w,h);pw=dw=w*f;ph=dh=h*f}
   pdf.addPage([pw,ph]).drawImage(im,{x:x,y:y,width:dw,height:dh});
  }
  function uniq(it,k,used){
   var base=(it.f.name||'').replace(/\.[^.]+$/,'').replace(/[^\w\- ]+/g,'_').trim().slice(0,50);
   if(!/[A-Za-z0-9]/.test(base))base='photo-'+(k+1);
   var nm=base,c=1;while(used[nm]){c++;nm=base+'-'+c}used[nm]=1;return nm+'.pdf';
  }
  function showOut(res,done,bad,shrunk){
   var h='<div class="ok">✓ Done!</div><p class="sub" style="margin:6px 0 14px">'+done+' photo'+(done>1?'s':'')+' → '+(res.length>1?res.length+' PDFs':'1 PDF')+(shrunk?'. The page was very long, so it was scaled down to fit the PDF page size limit.':'.')+(bad?' '+bad+' photo'+(bad>1?'s':'')+' could not be read and '+(bad>1?'were':'was')+' skipped.':'')+'</p>';
   res.forEach(function(o,i){
    var u=URL.createObjectURL(o.blob);outUrls.push(u);
    h+='<div class="ip-res"><span>'+esc(o.name)+' · '+size(o.blob.size)+'</span><span style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn dl" style="padding:9px 18px;font-size:15px" href="'+u+'" download="'+esc(o.name)+'">Download</a>'+(canShare?'<button type="button" class="btn" style="padding:9px 18px;font-size:15px" data-share="'+i+'">Share</button>':'')+'</span></div>'});
   if(res.length>1)h+='<div style="margin-top:14px"><button type="button" class="btn dl" id="ipzip">Download all (ZIP)</button></div>';
   h+='<p class="sub" style="margin:14px 0 0">Thank you for using LovePDFi.</p>';
   out.innerHTML=h;out.classList.add('show');
   out.querySelectorAll('[data-share]').forEach(function(b){b.onclick=async function(){var o=res[+b.dataset.share];try{await navigator.share({files:[new File([o.blob],o.name,{type:'application/pdf'})],title:o.name})}catch(e){}}});
   var z=$('ipzip');
   if(z)z.onclick=async function(){
    var btn=this;btn.disabled=true;btn.textContent='Preparing ZIP…';
    try{await lj('jszip');var zip=new JSZip();res.forEach(function(o){zip.file(o.name,o.blob)});var zb=await zip.generateAsync({type:'blob'});var a=document.createElement('a');a.href=URL.createObjectURL(zb);a.download='lovepdfi-pdfs.zip';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},2000)}
    catch(e){err('Could not create the ZIP. Please download the PDFs one by one.')}
    btn.disabled=false;btn.textContent='Download all (ZIP)'};
   out.scrollIntoView({behavior:'smooth',block:'nearest'});
  }
  run.onclick=async function(){
   if(!items.length)return;
   if(!pdfApi())return err('The PDF tools are still loading. Please try again in a moment.');
   resetOut();run.disabled=true;
   var PD=pdfApi().PDFDocument,res=[],bad=0,done=0,total=items.length,used={},doc=null,page=null,y=0,pw=0,f=1,W=595.28;
   try{
    if(mode==='long'){
     var H=items.reduce(function(s,it){return s+it.h*W/it.w},0);f=H>14400?14400/H:1;pw=W*f;doc=await PD.create();page=doc.addPage([pw,H*f]);y=H*f;
    }else if(mode==='one'){doc=await PD.create()}
    for(var k=0;k<total;k++){
     msg.textContent='Adding photo '+(k+1)+' of '+total+'…';
     var it=items[k];
     try{
      var p=await prep(it);
      if(mode==='sep'){var d=await PD.create(),im=await d.embedJpg(p.bytes);place(d,im,p.w,p.h);var b=await d.save({useObjectStreams:true});res.push({name:uniq(it,k,used),blob:new Blob([b],{type:'application/pdf'})})}
      else if(mode==='one'){var im2=await doc.embedJpg(p.bytes);place(doc,im2,p.w,p.h)}
      else{var im3=await doc.embedJpg(p.bytes),dh=it.h*W/it.w*f;y-=dh;page.drawImage(im3,{x:0,y:y,width:pw,height:dh})}
      done++;
     }catch(e){bad++}
    }
    if(!done)throw Error('none');
    if(mode!=='sep'){var bytes=await doc.save({useObjectStreams:true});res.push({name:'lovepdfi-'+(mode==='long'?'long-page':'photos')+'.pdf',blob:new Blob([bytes],{type:'application/pdf'})})}
    msg.textContent='';showOut(res,done,bad,mode==='long'&&f<1);
   }catch(e){err('Could not create the PDF. Try fewer or smaller photos, or choose Smaller file.')}
   run.disabled=!items.length;
  };
  function chips(attr,set,after){Q('['+attr+']').forEach(function(b){b.onclick=function(){set(b.getAttribute(attr));Q('['+attr+']').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')});resetOut();if(after)after()}})}
  chips('data-ipmode',function(v){mode=v},function(){$('ipnote').textContent=NOTES[mode];$('ipsizerow').hidden=mode==='long'});
  chips('data-ipsize',function(v){psize=v});
  chips('data-ipq',function(v){qual=v});
  $('ipsel').onclick=function(){inp.click()};
  inp.onchange=function(){var l=Array.from(this.files||[]);this.value='';add(l)};
  drop.onclick=function(){inp.click()};
  drop.onkeydown=function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();inp.click()}};
  ['dragenter','dragover'].forEach(function(ev){drop.addEventListener(ev,function(e){e.preventDefault();drop.classList.add('on')})});
  ['dragleave','drop'].forEach(function(ev){drop.addEventListener(ev,function(){drop.classList.remove('on')})});
  drop.addEventListener('drop',function(e){e.preventDefault();add(e.dataTransfer.files)});
  $('ipcam').onclick=function(){Cam.open({max:MAXP-items.length,title:'Take photos for your PDF',onDone:add})};
  $('ipclr').onclick=function(){items=[];resetOut();render();msg.textContent=''};
 })();

 var batch=null,batchUrls=[];
 function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
 function resetBatch(){batch=null;var bi=$('batchinfo'),bo=$('batchout');if(!bi)return;bi.hidden=true;bo.classList.remove('show');bo.innerHTML='';batchUrls.forEach(function(u){URL.revokeObjectURL(u)});batchUrls=[]}
 function setBatchOld(list0){hideBadge();normAll(list0).then(function(r){if(!r.files.length)return err('Please choose image files (JPG, PNG, WebP or iPhone HEIC).');setBatch2(r.files,r.kinds,r.bad)}).catch(function(){msg.textContent='';err('These images could not be read. Please try again.')})}
 function setBatch2(list,kinds,bad){
  list=list.filter(function(f){return /^image\//.test(f.type)});
  if(!list.length)return err('Please choose image files (JPG, PNG, WebP or iPhone HEIC).');
  var cut=list.length>30;if(cut)list=list.slice(0,30);
  resetBatch();batch=list;file=list[0];
  $('thumb').hidden=true;drop.hidden=true;
  var tot=list.reduce(function(s,f){return s+f.size},0);
  $('batchinfo').innerHTML='<b>'+list.length+' images selected</b> · '+size(tot)+'<br><small>'+list.slice(0,6).map(function(f){return esc(f.name)}).join(', ')+(list.length>6?' +'+(list.length-6)+' more':'')+(cut?'<br>Only the first 30 images were kept.':'')+'</small>';
  $('batchinfo').hidden=false;showBadge('Detected formats: <b>'+kindsText(kinds)+'</b>'+(bad?' · '+bad+' file(s) skipped':''));runs(true);msg.textContent='';$('done').classList.remove('show');
 }
 function loadImg(f){return new Promise(function(res,rej){var u=URL.createObjectURL(f),i=new Image();i.onload=function(){res({i:i,u:u})};i.onerror=function(){URL.revokeObjectURL(u);rej()};i.src=u})}
 async function batchRun(fn,kind){
  var out=[],fails=0,total=batch.length,_res=result,rw0=$('rw').value,rh0=$('rh').value,lock=$('lock').checked;
  result=function(bl,name,stats){out.push({b:bl,name:name,src:file})};
  try{
   for(var n=0;n<batch.length;n++){
    msg.textContent='Processing '+(n+1)+' of '+total+'…';
    file=batch[n];var L=null;
    try{
     L=await loadImg(file);img=L.i;ratio=img.naturalWidth/img.naturalHeight;
     if(kind==='resize'&&lock&&$('rw').value)$('rh').value=Math.round($('rw').value/ratio);
     var before=out.length;await fn();if(out.length===before)fails++;
    }catch(e){fails++}
    if(L)URL.revokeObjectURL(L.u);
   }
  }finally{result=_res;$('rw').value=rw0;$('rh').value=rh0}
  batchUrls.forEach(function(u){URL.revokeObjectURL(u)});batchUrls=[];
  var bo=$('batchout');
  var h='<div class="ok">✓ Done! '+out.length+' of '+total+' images</div>';
  if(fails)h+='<div class="err" style="margin-top:6px">'+fails+' could not be processed (the target may be too small, or the file is unreadable).</div>';
  h+='<div style="text-align:left;margin:14px 0">';
  out.forEach(function(o){var u=URL.createObjectURL(o.b);batchUrls.push(u);o.url=u;
   h+='<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--line)"><span style="font-size:15px;word-break:break-all">'+esc(o.name)+' · '+size(o.src.size)+' → '+size(o.b.size)+'</span><a class="btn dl" style="padding:7px 16px;font-size:14px" href="'+u+'" download="'+esc(o.name)+'">Download</a></div>'});
  h+='</div>';
  if(out.length>1)h+='<button class="btn dl" id="zipbtn">Download all (ZIP)</button>';
  h+='<p class="sub" style="margin:14px 0 0">Thank you for using LovePDFi.</p>';
  bo.innerHTML=h;bo.classList.add('show');msg.textContent='';
  var zb=$('zipbtn');
  if(zb)zb.onclick=async function(){
   var btn=this;btn.disabled=true;btn.textContent='Preparing ZIP…';
   try{await lj('jszip');var z=new JSZip(),used={};
    out.forEach(function(o){var nm=o.name,k=1;while(used[nm]){k++;nm=o.name.replace(/(\.[^.]+)$/,'-'+k+'$1')}used[nm]=1;z.file(nm,o.b)});
    var blobZip=await z.generateAsync({type:'blob'});var a=document.createElement('a');a.href=URL.createObjectURL(blobZip);a.download='lovepdfi-images.zip';document.body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},2000)}
   catch(e){err('Could not create the ZIP. Please download the images one by one.')}
   btn.disabled=false;btn.textContent='Download all (ZIP)'};
  bo.scrollIntoView({behavior:'smooth',block:'nearest'});
 }
 ['compress','convert','resize'].forEach(function(k){var o=run[k];run[k]=function(){return batch?batchRun(o,k):o()}});
 $('clr').addEventListener('click',resetBatch);$('tx').addEventListener('click',resetBatch);
var ScanLib=(function(){
 function gray(d,w,h){var g=new Uint8Array(w*h);for(var i=0,j=0;i<g.length;i++,j+=4)g[i]=(d[j]*299+d[j+1]*587+d[j+2]*114)/1000|0;return g}
 function shrink(d,w,h,maxS){var s=Math.min(1,maxS/Math.max(w,h)),nw=Math.max(1,Math.round(w*s)),nh=Math.max(1,Math.round(h*s)),o=new Uint8ClampedArray(nw*nh*4);
  for(var y=0;y<nh;y++){var sy=Math.min(h-1,Math.floor((y+0.5)/s));for(var x=0;x<nw;x++){var sx=Math.min(w-1,Math.floor((x+0.5)/s)),a=(sy*w+sx)*4,b=(y*nw+x)*4;o[b]=d[a];o[b+1]=d[a+1];o[b+2]=d[a+2];o[b+3]=255}}
  return {d:o,w:nw,h:nh,s:s}}
 function blur(g,w,h){var o=new Uint8Array(g.length);for(var y=0;y<h;y++)for(var x=0;x<w;x++){var s=0,c=0;for(var dy=-1;dy<=1;dy++){var yy=y+dy;if(yy<0||yy>=h)continue;for(var dx=-1;dx<=1;dx++){var xx=x+dx;if(xx<0||xx>=w)continue;s+=g[yy*w+xx];c++}}o[y*w+x]=s/c|0}return o}
 function otsu(g){var hst=new Array(256).fill(0),n=g.length,i;for(i=0;i<n;i++)hst[g[i]]++;var sum=0;for(i=0;i<256;i++)sum+=i*hst[i];var sB=0,wB=0,best=0,t=127;for(i=0;i<256;i++){wB+=hst[i];if(!wB)continue;var wF=n-wB;if(!wF)break;sB+=i*hst[i];var mB=sB/wB,mF=(sum-sB)/wF,v=wB*wF*(mB-mF)*(mB-mF);if(v>best){best=v;t=i}}return t}
 function area(q){var a=0;for(var i=0;i<4;i++){var p=q[i],r=q[(i+1)%4];a+=p.x*r.y-r.x*p.y}return Math.abs(a)/2}
 function bestComponent(mask,w,h){
  var lab=new Int32Array(w*h),stack=new Int32Array(w*h),res=null,id=0;
  for(var s=0;s<mask.length;s++){
   if(!mask[s]||lab[s])continue;id++;var sp=0,cnt=0;stack[sp++]=s;lab[s]=id;
   var tl=1e9,br=-1e9,tr=-1e9,bl=1e9,pTL,pBR,pTR,pBL,edge=0;
   while(sp){var p=stack[--sp],x=p%w,y=(p/w)|0;cnt++;
    var a=x+y,b=x-y;
    if(a<tl){tl=a;pTL={x:x,y:y}}if(a>br){br=a;pBR={x:x,y:y}}if(b>tr){tr=b;pTR={x:x,y:y}}if(b<bl){bl=b;pBL={x:x,y:y}}
    if(x===0||y===0||x===w-1||y===h-1)edge++;
    if(x>0&&mask[p-1]&&!lab[p-1]){lab[p-1]=id;stack[sp++]=p-1}
    if(x<w-1&&mask[p+1]&&!lab[p+1]){lab[p+1]=id;stack[sp++]=p+1}
    if(y>0&&mask[p-w]&&!lab[p-w]){lab[p-w]=id;stack[sp++]=p-w}
    if(y<h-1&&mask[p+w]&&!lab[p+w]){lab[p+w]=id;stack[sp++]=p+w}}
   if(cnt<w*h*0.08)continue;
   var q=[pTL,pTR,pBR,pBL],qa=area(q);if(qa<1)continue;
   var fill=cnt/qa,frac=cnt/(w*h);
   if(fill<0.72||frac>0.985||qa/(w*h)<0.1)continue;
   var cy=(pTL.y+pTR.y+pBR.y+pBL.y)/4;
   var topBias=1+(1-cy/h)*0.35;
   var score=frac*fill*(edge>(w+h)*0.8?0.4:1)*topBias;
   if(!res||score>res.score)res={score:score,q:q,bright:true}}
  return res}
 function detectQuad(d,w,h){
  var sh=shrink(d,w,h,320),g=blur(gray(sh.d,sh.w,sh.h),sh.w,sh.h),t=otsu(g),m1=new Uint8Array(g.length),m2=new Uint8Array(g.length);
  for(var i=0;i<g.length;i++){if(g[i]>t)m1[i]=1;else m2[i]=1}
  var r1=bestComponent(m1,sh.w,sh.h),r2=bestComponent(m2,sh.w,sh.h),r=r1;
  /* Prefer white/bright page (m1 = above Otsu threshold). Only take dark region if clearly better. */
  if(!r1)r=r2;else if(r2&&r2.score>r1.score*1.6)r=r2;
  if(!r)return null;
  return r.q.map(function(p){return {x:Math.min(w-1,Math.max(0,(p.x+0.5)/sh.s)),y:Math.min(h-1,Math.max(0,(p.y+0.5)/sh.s))}})}
 function defaultQuad(w,h){var mx=w*0.06,my=h*0.06;return [{x:mx,y:my},{x:w-mx,y:my},{x:w-mx,y:h-my},{x:mx,y:h-my}]}
 function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
 function solve(A,b){var n=b.length,i,j,k;for(i=0;i<n;i++){var m=i;for(j=i+1;j<n;j++)if(Math.abs(A[j][i])>Math.abs(A[m][i]))m=j;var t=A[i];A[i]=A[m];A[m]=t;var tb=b[i];b[i]=b[m];b[m]=tb;
   for(j=i+1;j<n;j++){var f=A[j][i]/A[i][i];for(k=i;k<n;k++)A[j][k]-=f*A[i][k];b[j]-=f*b[i]}}
  var x=new Array(n);for(i=n-1;i>=0;i--){var s=b[i];for(j=i+1;j<n;j++)s-=A[i][j]*x[j];x[i]=s/A[i][i]}return x}
 function homography(dst,src){var A=[],b=[];for(var i=0;i<4;i++){var x=dst[i].x,y=dst[i].y,u=src[i].x,v=src[i].y;
   A.push([x,y,1,0,0,0,-x*u,-y*u]);b.push(u);A.push([0,0,0,x,y,1,-x*v,-y*v]);b.push(v)}
  return solve(A,b)}
 function outSize(q,maxS){var W=Math.max(dist(q[0],q[1]),dist(q[3],q[2])),H=Math.max(dist(q[0],q[3]),dist(q[1],q[2])),s=Math.min(1,maxS/Math.max(W,H));return {w:Math.max(8,Math.round(W*s)),h:Math.max(8,Math.round(H*s))}}
 function warp(d,w,h,q,ow,oh){
  var H=homography([{x:0,y:0},{x:ow,y:0},{x:ow,y:oh},{x:0,y:oh}],q),o=new Uint8ClampedArray(ow*oh*4);
  for(var y=0;y<oh;y++)for(var x=0;x<ow;x++){var den=H[6]*x+H[7]*y+1,sx=(H[0]*x+H[1]*y+H[2])/den,sy=(H[3]*x+H[4]*y+H[5])/den,k=(y*ow+x)*4;
   if(sx<0)sx=0;if(sy<0)sy=0;if(sx>w-1)sx=w-1;if(sy>h-1)sy=h-1;
   var x0=sx|0,y0=sy|0,x1=Math.min(w-1,x0+1),y1=Math.min(h-1,y0+1),fx=sx-x0,fy=sy-y0,a=(y0*w+x0)*4,b=(y0*w+x1)*4,c=(y1*w+x0)*4,e=(y1*w+x1)*4;
   for(var ch=0;ch<3;ch++)o[k+ch]=(d[a+ch]*(1-fx)+d[b+ch]*fx)*(1-fy)+(d[c+ch]*(1-fx)+d[e+ch]*fx)*fy;o[k+3]=255}
  return o}
 function rotate90(d,w,h,cw){var o=new Uint8ClampedArray(d.length),nw=h,nh=w;
  for(var y=0;y<h;y++)for(var x=0;x<w;x++){var nx=cw?h-1-y:y,ny=cw?x:w-1-x,a=(y*w+x)*4,b=(ny*nw+nx)*4;o[b]=d[a];o[b+1]=d[a+1];o[b+2]=d[a+2];o[b+3]=255}
  return {d:o,w:nw,h:nh}}
 function toGray(d){for(var i=0;i<d.length;i+=4){var v=(d[i]*299+d[i+1]*587+d[i+2]*114)/1000;d[i]=d[i+1]=d[i+2]=v}return d}
 function enhance(d,w,h){var hist=new Array(256).fill(0),n=w*h,i;for(i=0;i<d.length;i+=4)hist[(d[i]*299+d[i+1]*587+d[i+2]*114)/1000|0]++;
  var lo=0,hi=255,c=0;for(i=0;i<256;i++){c+=hist[i];if(c>n*0.01){lo=i;break}}c=0;for(i=255;i>=0;i--){c+=hist[i];if(c>n*0.01){hi=i;break}}
  if(hi-lo<20){lo=0;hi=255}var sc=255/(hi-lo);
  for(i=0;i<d.length;i+=4)for(var ch=0;ch<3;ch++){var v=(d[i+ch]-lo)*sc;d[i+ch]=v<0?0:v>255?255:v}return d}
 function bw(d,w,h){var g=gray(d,w,h),W=w+1,I=new Float64Array(W*(h+1)),x,y;
  for(y=0;y<h;y++){var rs=0;for(x=0;x<w;x++){rs+=g[y*w+x];I[(y+1)*W+x+1]=I[y*W+x+1]+rs}}
  var r=Math.max(7,Math.round(Math.min(w,h)/24));
  for(y=0;y<h;y++)for(x=0;x<w;x++){var x0=Math.max(0,x-r),x1=Math.min(w,x+r+1),y0=Math.max(0,y-r),y1=Math.min(h,y+r+1),cnt=(x1-x0)*(y1-y0),s=I[y1*W+x1]-I[y0*W+x1]-I[y1*W+x0]+I[y0*W+x0],m=s/cnt,v=g[y*w+x]<m*0.9?0:255,k=(y*w+x)*4;d[k]=d[k+1]=d[k+2]=v}
  return d}
 return {detectQuad:detectQuad,defaultQuad:defaultQuad,outSize:outSize,warp:warp,rotate90:rotate90,toGray:toGray,enhance:enhance,bw:bw,dist:dist,area:area};
})();


 (function(){
  var SL=ScanLib;
  function blobToCanvas(bl,maxS){return new Promise(function(res,rej){var u=URL.createObjectURL(bl),i=new Image();i.onload=function(){var s=Math.min(1,maxS/Math.max(i.naturalWidth,i.naturalHeight)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(i.naturalWidth*s));c.height=Math.max(1,Math.round(i.naturalHeight*s));var x=c.getContext('2d');/* no white fill — avoid extra border */x.drawImage(i,0,0,c.width,c.height);URL.revokeObjectURL(u);res(c)};i.onerror=function(){URL.revokeObjectURL(u);rej(new Error('read'))};i.src=u})}
  function canvasToBlob(c,q){return new Promise(function(res){c.toBlob(res,'image/jpeg',q||0.92)})}
  function thumbOfCanvas(c){var s=Math.min(1,160/Math.max(c.width,c.height)),t=document.createElement('canvas');t.width=Math.max(1,Math.round(c.width*s));t.height=Math.max(1,Math.round(c.height*s));t.getContext('2d').drawImage(c,0,0,t.width,t.height);return t.toDataURL('image/jpeg',0.6)}
  function cvData(c){return c.getContext('2d').getImageData(0,0,c.width,c.height)}
  function putData(d,w,h){var c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').putImageData(new ImageData(d,w,h),0,0);return c}
  function applyFilter(d,w,h,f){if(f==='enh')SL.enhance(d,w,h);else if(f==='gray')SL.toGray(d);else if(f==='bw')SL.bw(d,w,h);return d}
  function rotCanvas(c,deg){deg=((deg%360)+360)%360;if(!deg)return c;var o=document.createElement('canvas');o.width=deg===180?c.width:c.height;o.height=deg===180?c.height:c.width;var x=o.getContext('2d');x.translate(o.width/2,o.height/2);x.rotate(deg*Math.PI/180);x.drawImage(c,-c.width/2,-c.height/2);return o}
  async function rotBlob(bl,deg){return canvasToBlob(rotCanvas(await blobToCanvas(bl,3000),deg),0.92)}
  window.rotBlob=rotBlob;
  async function autoProcess(bl,filter,auto){
   var c=await blobToCanvas(bl,2600),out=c,q=null,im=cvData(c);
   if(auto){q=SL.detectQuad(im.data,c.width,c.height);
    if(q){var os=SL.outSize(q,2200),wd=SL.warp(im.data,c.width,c.height,q,os.w,os.h);applyFilter(wd,os.w,os.h,filter);out=putData(wd,os.w,os.h)}}
   if(!q&&filter!=='orig'){applyFilter(im.data,c.width,c.height,filter);out=putData(im.data,c.width,c.height)}
   return {blob:await canvasToBlob(out),canvas:out,found:!!q}}

  /* ---------------- page editor (crop corners, rotate, filters) ---------------- */
  var ED={S:null,srcC:null,q:null,mode:'edit',filt:'enh',drag:-1,sc:1,cb:null,prevC:null},edc=$('edc');
  function edShow(on){$('edov').hidden=!on;document.body.style.overflow=on?'hidden':''}
  function edLayout(){var st=$('edstage'),S=ED.S;if(!S)return;var W=st.clientWidth||300,H=st.clientHeight||300,s=Math.min(W/S.w,H/S.h);ED.sc=s;edc.width=Math.max(1,Math.round(S.w*s));edc.height=Math.max(1,Math.round(S.h*s));edDraw()}
  function edDraw(){
   var x=edc.getContext('2d');x.clearRect(0,0,edc.width,edc.height);
   if(ED.mode==='prev'&&ED.prevC){var s=Math.min(edc.width/ED.prevC.width,edc.height/ED.prevC.height),w=ED.prevC.width*s,h=ED.prevC.height*s;x.fillStyle='#222';x.fillRect(0,0,edc.width,edc.height);x.drawImage(ED.prevC,(edc.width-w)/2,(edc.height-h)/2,w,h);return}
   x.drawImage(ED.srcC,0,0,edc.width,edc.height);
   var q=ED.q,k=ED.sc;x.fillStyle='rgba(0,0,0,.45)';x.beginPath();x.rect(0,0,edc.width,edc.height);x.moveTo(q[0].x*k,q[0].y*k);for(var i=3;i>=0;i--)x.lineTo(q[i].x*k,q[i].y*k);x.closePath();x.fill('evenodd');
   x.strokeStyle='#38bdf8';x.lineWidth=2.5;x.beginPath();q.forEach(function(p,i){i?x.lineTo(p.x*k,p.y*k):x.moveTo(p.x*k,p.y*k)});x.closePath();x.stroke();
   q.forEach(function(p){x.beginPath();x.arc(p.x*k,p.y*k,13,0,7);x.fillStyle='#fff';x.fill();x.lineWidth=3;x.strokeStyle='#0284c7';x.stroke()})}
  function edFilterUi(){Q('[data-ef]').forEach(function(b){b.setAttribute('aria-pressed',b.dataset.ef===ED.filt?'true':'false')})}
  function edRender(maxS){var S=ED.S,os=SL.outSize(ED.q,maxS),wd=SL.warp(S.d,S.w,S.h,ED.q,os.w,os.h);applyFilter(wd,os.w,os.h,ED.filt);return putData(wd,os.w,os.h)}
  async function edOpen(bl,cb,opts){
   try{var c=await blobToCanvas(bl,2600),im=cvData(c);
    ED.srcC=c;ED.S={d:im.data,w:c.width,h:c.height};ED.q=SL.detectQuad(im.data,c.width,c.height)||SL.defaultQuad(c.width,c.height);
    ED.filt=(opts&&opts.filter)||'enh';ED.mode='edit';ED.cb=cb;edFilterUi();$('edprev').textContent='Preview';edShow(true);edLayout()}
   catch(e){err('This page could not be opened for editing.')}}
  function edRot(cw){var S=ED.S,r=SL.rotate90(S.d,S.w,S.h,cw),m=ED.q.map(function(p){return cw?{x:S.h-p.y,y:p.x}:{x:p.y,y:S.w-p.x}});
   ED.q=cw?[m[3],m[0],m[1],m[2]]:[m[1],m[2],m[3],m[0]];ED.S={d:r.d,w:r.w,h:r.h};ED.srcC=putData(new Uint8ClampedArray(r.d),r.w,r.h);ED.mode='edit';$('edprev').textContent='Preview';edLayout()}
  edc.addEventListener('pointerdown',function(e){if(ED.mode!=='edit')return;var r=edc.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top,best=-1,bd=40;
   ED.q.forEach(function(p,i){var d=Math.hypot(p.x*ED.sc-x,p.y*ED.sc-y);if(d<bd){bd=d;best=i}});
   if(best>=0){ED.drag=best;try{edc.setPointerCapture(e.pointerId)}catch(_){}e.preventDefault()}});
  edc.addEventListener('pointermove',function(e){if(ED.drag<0)return;var r=edc.getBoundingClientRect(),S=ED.S;
   ED.q[ED.drag]={x:Math.max(0,Math.min(S.w,(e.clientX-r.left)/ED.sc)),y:Math.max(0,Math.min(S.h,(e.clientY-r.top)/ED.sc))};edDraw();e.preventDefault()});
  ['pointerup','pointercancel'].forEach(function(v){edc.addEventListener(v,function(){ED.drag=-1})});
  window.addEventListener('resize',function(){if(!$('edov').hidden)edLayout()});
  $('edauto').onclick=function(){var S=ED.S;ED.q=SL.detectQuad(S.d,S.w,S.h)||SL.defaultQuad(S.w,S.h);ED.mode='edit';$('edprev').textContent='Preview';edDraw()};
  $('edfull').onclick=function(){var S=ED.S;ED.q=[{x:0,y:0},{x:S.w,y:0},{x:S.w,y:S.h},{x:0,y:S.h}];ED.mode='edit';$('edprev').textContent='Preview';edDraw()};
  $('edrl').onclick=function(){edRot(false)};$('edrr').onclick=function(){edRot(true)};
  Q('[data-ef]').forEach(function(b){b.onclick=function(){ED.filt=b.dataset.ef;edFilterUi();if(ED.mode==='prev'){ED.prevC=edRender(1000);edDraw()}}});
  $('edprev').onclick=function(){if(ED.mode==='prev'){ED.mode='edit';this.textContent='Preview'}else{ED.prevC=edRender(1000);ED.mode='prev';this.textContent='Edit corners'}edDraw()};
  $('edx').onclick=function(){edShow(false);ED.S=null};
  $('eddone').onclick=async function(){var bt=this;bt.disabled=true;
   try{var c=edRender(2200),bl=await canvasToBlob(c,0.92),cb=ED.cb;edShow(false);ED.S=null;if(cb)await cb(bl,c)}catch(e){err('Could not apply the changes.')}
   bt.disabled=false};

  /* ---------------- camera with frame guide, live document outline and angle lock ---------------- */
  var CM={stream:null,cfg:null,count:0,lockMode:'auto',lockO:null,lockA:null,tmr:0,busy:false,ds:document.createElement('canvas')};
  function angleNow(){var a=null;if(screen.orientation&&typeof screen.orientation.angle==='number')a=screen.orientation.angle;else if(typeof window.orientation==='number')a=window.orientation;return a===null?null:((a%360)+360)%360}
  function updLock(){Q('[data-lock]').forEach(function(b){b.setAttribute('aria-pressed',b.dataset.lock===CM.lockMode?'true':'false')});
   $('camlockinfo').textContent=CM.lockMode==='auto'?(CM.lockO?'🔒 '+(CM.lockO==='portrait'?'Portrait':'Landscape')+' locked by first photo':'First photo sets the angle'):'🔒 '+(CM.lockMode==='portrait'?'Portrait':'Landscape')}
  function brackets(x,gx,gy,gw,gh){var L=Math.min(gw,gh)*0.1;x.strokeStyle='rgba(255,255,255,.95)';x.lineWidth=4;x.lineCap='round';
   [[gx,gy,1,1],[gx+gw,gy,-1,1],[gx+gw,gy+gh,-1,-1],[gx,gy+gh,1,-1]].forEach(function(c){x.beginPath();x.moveTo(c[0],c[1]+c[3]*L);x.lineTo(c[0],c[1]);x.lineTo(c[0]+c[2]*L,c[1]);x.stroke()})}
  function camTick(){
   var v=$('camv'),fx=$('camfx');if(!CM.stream||!v.videoWidth)return;
   var r=v.getBoundingClientRect(),W=Math.round(r.width),H=Math.round(r.height);if(fx.width!==W||fx.height!==H){fx.width=W;fx.height=H}
   var x=fx.getContext('2d');x.clearRect(0,0,W,H);var vw=v.videoWidth,vh=v.videoHeight,s=Math.min(W/vw,H/vh),ox=(W-vw*s)/2,oy=(H-vh*s)/2;
   brackets(x,ox+vw*s*0.07,oy+vh*s*0.07,vw*s*0.86,vh*s*0.86);
   /* Live detection off — detect white page only after capture, then crop + straighten */
   $('camhint').textContent='Place the white page inside the frame, then tap the round button.';
  }
  function camClose(){clearInterval(CM.tmr);if(CM.stream){CM.stream.getTracks().forEach(function(t){t.stop()});CM.stream=null}$('camv').srcObject=null;$('camov').hidden=true;document.body.style.overflow='';var cfg=CM.cfg,n=CM.count;CM.cfg=null;if(cfg&&cfg.onClose)cfg.onClose(n)}
  async function camOpen(cfg){
   if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)throw new Error('nocam');
   var st=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:2560},height:{ideal:1440}},audio:false});
   CM.stream=st;CM.cfg=cfg;CM.count=0;CM.lockMode='auto';CM.lockO=null;CM.lockA=null;
   var v=$('camv');v.srcObject=st;
   try{await v.play()}catch(e){camClose();throw e}
   $('camov').hidden=false;document.body.style.overflow='hidden';$('camcount').textContent='';updLock();CM.tmr=setInterval(camTick,300)}
  async function camShot(){
   if(CM.busy||!CM.stream)return;var v=$('camv'),w=v.videoWidth,h=v.videoHeight;if(!w)return;CM.busy=true;
   try{var c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(v,0,0,w,h);
    /* Keep capture orientation exactly as the phone is held (video stream matches device).
       Only force rotation when user explicitly locked Portrait or Landscape. */
    var fo=w>=h?'landscape':'portrait',rot=0;
    if(CM.lockMode==='auto'){if(CM.lockO===null){CM.lockO=fo;CM.lockA=angleNow();updLock()}}
    else{
     var target=CM.lockMode;
     if(fo!==target)rot=90;
    }
    if(rot)c=rotCanvas(c,rot);
    var bl=await canvasToBlob(c,0.92);CM.count++;$('camcount').textContent=CM.count+' captured';
    var fl=$('camflash');fl.style.opacity='.8';setTimeout(function(){fl.style.opacity='0'},120);
    /* Do not block shutter on heavy post-processing */
    CM.busy=false;
    if(CM.cfg&&CM.cfg.onShot){Promise.resolve(CM.cfg.onShot(bl)).catch(function(){})}
    if(CM.cfg&&!CM.cfg.multi)camClose()}
   catch(e){err('Could not capture the photo. Please try again.');CM.busy=false}
  }
  $('camshot2').onclick=camShot;$('camx').onclick=camClose;$('camdone').onclick=camClose;
  Q('[data-lock]').forEach(function(b){b.onclick=function(){CM.lockMode=b.dataset.lock;if(CM.lockMode==='auto'){CM.lockO=null;CM.lockA=null}updLock()}});
  document.addEventListener('visibilitychange',function(){if(document.hidden&&CM.stream)camClose()});
  window.addEventListener('pagehide',function(){if(CM.stream)camClose()});
  function camFail(e,fallback){if(e&&e.name==='NotAllowedError')err('Camera permission was denied. Allow camera access in your browser settings, or choose files instead.');else if(fallback)fallback();else err('Could not start the camera. Choose files instead.')}

  /* image tools: Take photo uses the new camera (frame + angle lock), several shots allowed */
  $('camshot').onclick=async function(){
   var shots=[];
   try{await camOpen({multi:true,detect:false,onShot:function(b){shots.push(b)},onClose:function(){
     if(!shots.length)return;var fl=shots.map(function(b,i){return new File([b],'camera-photo-'+(i+1)+'.jpg',{type:'image/jpeg'})});if(fl.length===1)pick(fl[0]);else setBatch(fl)}})}
   catch(e){camFail(e,function(){var i=document.createElement('input');i.type='file';i.accept='image/*';i.setAttribute('capture','environment');i.hidden=true;i.onchange=function(){var f=this.files&&this.files[0];i.remove();if(f)pick(f)};document.body.appendChild(i);i.click()})}};

  /* ---------------- shared PDF helpers ---------------- */
  var QM={high:{q:0.92,m:3000},bal:{q:0.8,m:2000},small:{q:0.6,m:1400}};
  async function jpgInfo(bl,cfg){var c=await blobToCanvas(bl,cfg.m),b=await canvasToBlob(c,cfg.q);return {bytes:new Uint8Array(await b.arrayBuffer()),w:c.width,h:c.height}}
  function addImgPage(doc,im,J,size){var pw,ph,x,y,dw,dh;
   if(size==='fit'){pw=J.w*0.75;ph=J.h*0.75;x=0;y=0;dw=pw;dh=ph}
   else{var land=J.w>J.h;pw=land?841.89:595.28;ph=land?595.28:841.89;/* no margin — image fills page edge-to-edge, no white border */var m=0,s=Math.min((pw-2*m)/J.w,(ph-2*m)/J.h);dw=J.w*s;dh=J.h*s;x=(pw-dw)/2;y=(ph-dh)/2}
   doc.addPage([pw,ph]).drawImage(im,{x:x,y:y,width:dw,height:dh})}
  var outUrl=null;
  function showPdf(el,bytes,name,pages){
   if(outUrl)URL.revokeObjectURL(outUrl);var bl=new Blob([bytes],{type:'application/pdf'});outUrl=URL.createObjectURL(bl);
   el.innerHTML='<div class="ok">✓ Done! Your PDF is ready</div><div class="sub">'+size(bl.size)+' · '+pages+' page'+(pages>1?'s':'')+'</div><p style="margin:14px 0"><a class="btn dl" href="'+outUrl+'" download="'+esc(easyToolsTimestampFilename(name))+'" data-et-base-name="'+esc(name)+'">Download PDF</a></p><p class="sub" style="margin:0">Thank you for using LovePDFi.</p>';
   el.classList.add('show');msg.textContent='';el.scrollIntoView({behavior:'smooth',block:'nearest'})}
  function gridHtml(items,sel){return items.map(function(it,i){return '<div class="sc-item'+(sel===i?' sel':'')+'" data-sel="'+i+'"><img alt="Page '+(i+1)+'" src="'+it.thumb+'"'+(it.t==='pdf'&&it.rot?' style="transform:rotate('+it.rot+'deg)"':'')+'><span>'+(i+1)+'</span><div><button data-i="'+i+'" data-a="ed" aria-label="Edit page">✎</button><button data-i="'+i+'" data-a="rl" aria-label="Rotate left">↺</button><button data-i="'+i+'" data-a="rr" aria-label="Rotate right">↻</button><button data-i="'+i+'" data-a="up" aria-label="Move earlier">←</button><button data-i="'+i+'" data-a="dn" aria-label="Move later">→</button><button data-i="'+i+'" data-a="rm" aria-label="Delete page">✕</button></div></div>'}).join('')}
  var LB={src:null};
  function lbShow(src){if(!src)return;$('lbimg').src=src;$('lightbox').hidden=false;document.body.style.overflow='hidden'}
  function lbHide(){$('lightbox').hidden=true;$('lbimg').src='';document.body.style.overflow=''}
  window.lbShow=lbShow;
  if($('lbx'))$('lbx').onclick=lbHide;
  if($('lightbox'))$('lightbox').onclick=function(e){if(e.target===$('lightbox')||e.target===$('lbimg'))lbHide()};
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&$('lightbox')&&!$('lightbox').hidden)lbHide()});
  function blobUrl(bl){return URL.createObjectURL(bl)}
  async function prevSrc(it){
   if(it.blob)return blobUrl(it.blob);
   if(it.t==='pdf'&&typeof EP!=='undefined'&&EP.doc){
    try{var pg=await EP.doc.getPage(it.idx+1),vp=pg.getViewport({scale:1.5,rotation:it.rot||0}),c=document.createElement('canvas');
     c.width=Math.round(vp.width);c.height=Math.round(vp.height);
     await pg.render({canvasContext:c.getContext('2d'),viewport:vp}).promise;return c.toDataURL('image/jpeg',0.92)}catch(e){return it.thumb}
   }
   return it.thumb||''}

  function moveItem(items,i,a){if(a==='up'&&i>0){items.splice(i-1,0,items.splice(i,1)[0]);return i-1}if(a==='dn'&&i<items.length-1){items.splice(i+1,0,items.splice(i,1)[0]);return i+1}return i}
  document.addEventListener('lovepdfi:pdfedit-reorder',function(e){
   var d=e.detail||{},from=Number(d.from),to=Number(d.to);
   if(!Number.isInteger(from)||!Number.isInteger(to)||from<0||to<0||from>=EP.items.length||to>=EP.items.length||from===to)return;
   var picked=EP.items.splice(from,1)[0];EP.items.splice(to,0,picked);EP.sel=to;epRender();
  });
  function cap(n){return n+' page'+(n===1?'':'s')}

  /* ---------------- Scan Document (camera / images -> auto crop -> PDF) ---------------- */
  var SC={items:[],filter:'enh',size:'fit',q:'bal',sel:0};
  async function scShowPrev(){
   var box=$('scPrev'),img=$('scPrevImg');if(!box||!img)return;
   if(!SC.items.length){box.hidden=true;img.src='';return}
   if(SC.sel<0||SC.sel>=SC.items.length)SC.sel=0;
   var it=SC.items[SC.sel];box.hidden=false;img.src=await prevSrc(it);
  }
  function scRender(){$('scGrid').innerHTML=gridHtml(SC.items,SC.sel);$('scInfo').textContent=SC.items.length?cap(SC.items.length)+' ready':'';$('scRun').disabled=!SC.items.length;$('scClear').disabled=!SC.items.length;scShowPrev();document.dispatchEvent(new CustomEvent('lovepdfi:image-gallery-update',{detail:{mode:'scan',items:SC.items.map(function(it,i){var bl=it.blob||it.orig;if(!it._psgBlob||it._psgBlob!==bl){if(it._psgUrl)URL.revokeObjectURL(it._psgUrl);it._psgBlob=bl;it._psgUrl=URL.createObjectURL(bl)}return {src:it._psgUrl,name:'Page '+(i+1)}}),selected:SC.sel,select:function(i){SC.sel=i;scShowPrev()},action:function(i,a){var card=$('scGrid').querySelector('[data-sel="'+i+'"]');if(!card)return;var map={up:'up',dn:'dn',rl:'rl',rr:'rr',ed:'ed',rm:'rm'},bt=card.querySelector('button[data-a="'+map[a]+'"]');if(bt)bt.click()}}}))}
  document.addEventListener('lovepdfi:request-image-gallery',function(e){if(!e.detail||e.detail.mode==='scan')scRender()});
  async function scAdd(files,isCam){
   var auto=$('scAuto').checked;
   for(var i=0;i<files.length;i++){
    if(SC.items.length>=60){err('Maximum 60 pages.');break}
    try{msg.textContent='Processing page '+(SC.items.length+1)+'…';var f=files[i];
     if(!isCam){var n=await normImg(f);f=n.file}
     var r=await autoProcess(f,SC.filter,auto);SC.items.push({orig:f,blob:r.blob,thumb:thumbOfCanvas(r.canvas)});scRender()}
    catch(e){err('A page could not be read. Use JPG, PNG, WebP or HEIC images.')}}
   if(!$('msg').querySelector('.err'))msg.textContent='';scRender()}
  $('scCam').onclick=async function(){
   try{await camOpen({multi:true,detect:true,onShot:function(b){return scAdd([b],true)}})}catch(e){camFail(e,function(){$('scFile').click()})}};
  $('scAdd').onclick=function(){$('scFile').click()};
  $('scFile').onchange=function(){var fl=Array.prototype.slice.call(this.files);this.value='';scAdd(fl,false)};
  Q('[data-scf]').forEach(function(b){b.onclick=function(){SC.filter=b.dataset.scf;Q('[data-scf]').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')})}});
  Q('[data-scs]').forEach(function(b){b.onclick=function(){var k=b.dataset.scs;SC[k]=b.dataset.v;Q('[data-scs="'+k+'"]').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')})}});
  $('scGrid').onclick=async function(e){
   var card=e.target.closest('[data-sel]');
   if(card&&!e.target.closest('button')){SC.sel=+card.dataset.sel;scRender();return}
   var bt=e.target.closest('button');if(!bt)return;var i=+bt.dataset.i,a=bt.dataset.a,it=SC.items[i];if(!it)return;SC.sel=i;
   if(a==='rm')SC.items.splice(i,1);else if(a==='up'||a==='dn')moveItem(SC.items,i,a);
   else if(a==='rl'||a==='rr'){var d=a==='rr'?90:270;it.blob=await rotBlob(it.blob,d);it.orig=await rotBlob(it.orig,d);it.thumb=thumbOfCanvas(await blobToCanvas(it.blob,300))}
   else if(a==='ed'){return edOpen(it.orig,async function(bl,c){it.blob=bl;it.thumb=thumbOfCanvas(c);scRender()},{filter:SC.filter})}
   scRender()};
  async function scDoRot(d){var it=SC.items[SC.sel];if(!it)return;it.blob=await rotBlob(it.blob,d);it.orig=await rotBlob(it.orig,d);it.thumb=thumbOfCanvas(await blobToCanvas(it.blob,300));scRender()}
  if($('scPrevRL'))$('scPrevRL').onclick=function(){scDoRot(270)};
  if($('scPrevRR'))$('scPrevRR').onclick=function(){scDoRot(90)};
  if($('scPrevEd'))$('scPrevEd').onclick=function(){var it=SC.items[SC.sel];if(!it)return;edOpen(it.orig,async function(bl,c){it.blob=bl;it.thumb=thumbOfCanvas(c);scRender()},{filter:SC.filter})};
  if($('scPrevFs'))$('scPrevFs').onclick=function(){var s=$('scPrevImg')&&$('scPrevImg').src;if(s)lbShow(s)};
  if($('scPrevStage'))$('scPrevStage').ondblclick=function(){var s=$('scPrevImg')&&$('scPrevImg').src;if(s)lbShow(s)};
  $('scClear').onclick=function(){SC.items=[];SC.sel=0;scRender();$('scout').classList.remove('show');msg.textContent=''};

  $('scRun').onclick=async function(){
   if(!SC.items.length)return;var bt=this;bt.disabled=true;msg.textContent='Creating PDF…';
   try{await loadFor('pdf');var doc=await PDFLib.PDFDocument.create(),cfg=QM[SC.q];
    for(var n=0;n<SC.items.length;n++){msg.textContent='Adding page '+(n+1)+' of '+SC.items.length+'…';var J=await jpgInfo(SC.items[n].blob,cfg);addImgPage(doc,await doc.embedJpg(J.bytes),J,SC.size)}
    showPdf($('scout'),await doc.save(),'scan.pdf',SC.items.length)}
   catch(e){err('Could not create the PDF. Try fewer pages or the Small file option.')}
   bt.disabled=!SC.items.length};

  /* ---------------- Edit PDF (rotate, delete, reorder, edit page, add images) ---------------- */
  var EP={items:[],doc:null,bytes:null,name:'edited',sel:0,src:null,pages:0,failed:null,loading:null};
  /* EP is the editable WORKING copy of PDFShared.files[0]. It differs from the original only when pages were changed. */
  function epIsDirty(){
   if(!EP.items.length)return false;
   if(!EP.src)return true;
   if(EP.items.length!==EP.pages)return true;
   return EP.items.some(function(it,i){return it.t!=='pdf'||it.idx!==i||(it.rot||0)!==0})}
  function epReset(){EP.items=[];EP.doc=null;EP.bytes=null;EP.sel=0;EP.src=null;EP.pages=0;EP.failed=null;epRender();var o=$('scout2');if(o)o.classList.remove('show')}
  function epFail(f){EP.items=[];EP.doc=null;EP.bytes=null;EP.sel=0;EP.src=null;EP.pages=0;EP.failed=f;epRender()}
  function epSync(){var f=PS.first();if(!f||EP.src===f||EP.failed===f||EP.loading===f)return;epLoad(f)}
  PS.edit={isDirty:epIsDirty,reset:epReset,pending:function(){var f=PS.first();return !!f&&EP.src!==f&&EP.failed!==f}};
  PS.on(function(){if(PS.tool==='pdfedit')epSync()});
  async function epShowPrev(){
   var box=$('epPrev'),img=$('epPrevImg');if(!box||!img)return;
   if(!EP.items.length){box.hidden=true;img.src='';return}
   if(EP.sel<0||EP.sel>=EP.items.length)EP.sel=0;
   box.hidden=false;img.src=await prevSrc(EP.items[EP.sel]);
  }
  function epRender(){$('epGrid').innerHTML=gridHtml(EP.items,EP.sel);$('epInfo').textContent=EP.items.length?cap(EP.items.length)+(EP.doc?' · '+esc(EP.name)+'.pdf':''):'';$('epRun').disabled=!EP.items.length;$('epClear').disabled=!EP.items.length;epShowPrev();document.dispatchEvent(new CustomEvent('lovepdfi:pdfedit-gallery',{detail:{items:EP.items.map(function(it,i){return {thumb:it.thumb,blob:it.t==='img'?(it.blob||it.orig):null,rot:it.t==='pdf'?(it.rot||0):0,label:(i+1)+'. '+(it.t==='pdf'?'PDF page':'Added image'),index:i}}),selected:EP.sel,name:EP.name||'PDF',edited:epIsDirty()}}))}
  async function epLoad(f){
   EP.loading=f;
   try{
    try{await loadFor('pdf')}catch(e){return err('Could not load the PDF tools. Check your internet and try again.')}
    msg.textContent='Reading PDF…';var d;
    try{d=await PS.load(f)}catch(e){msg.textContent='';if(PS.first()===f)epFail(f);return err(e&&e.name==='PasswordException'?'This PDF is password protected, so it cannot be edited here.':'This PDF could not be read.')}
    if(d.doc.numPages>100){if(PS.first()===f)epFail(f);return err('Please use a PDF with up to 100 pages.')}
    var items=[];
    try{for(var i=1;i<=d.doc.numPages;i++){if(PS.first()!==f){msg.textContent='';return}msg.textContent='Reading page '+i+' of '+d.doc.numPages+'…';items.push({t:'pdf',idx:i-1,rot:0,thumb:await PS.renderPage(f,i)})}}
    catch(e){msg.textContent='';if(PS.first()===f)epFail(f);return err('This PDF could not be read.')}
    if(PS.first()!==f){msg.textContent='';return}
    EP.doc=d.doc;EP.bytes=d.bytes;EP.name=f.name.replace(/\.pdf$/i,'');EP.items=items;EP.sel=0;EP.src=f;EP.pages=items.length;EP.failed=null;
    msg.textContent='';epRender();
   }finally{if(EP.loading===f)EP.loading=null}}
  async function epAddImgs(files,isCam,auto){
   for(var i=0;i<files.length;i++){
    if(EP.items.length>=150){err('Too many pages.');break}
    try{msg.textContent='Adding image '+(i+1)+'…';var f=files[i];if(!isCam){var n=await normImg(f);f=n.file}
     var r=auto?await autoProcess(f,'enh',true):null,bl=r?r.blob:f,th=r?r.canvas:await blobToCanvas(f,400);
     EP.items.push({t:'img',orig:f,blob:bl,thumb:thumbOfCanvas(th)});epRender()}
    catch(e){err('An image could not be read. Use JPG, PNG, WebP or HEIC images.')}}
   if(!$('msg').querySelector('.err'))msg.textContent='';epRender()}
  $('epSel').onclick=function(){$('epFile').click()};
  $('epFile').onchange=function(){var f=this.files[0];this.value='';if(f)PS.setFiles([f],'pdfedit')};
  $('epAddImg').onclick=function(){$('epImgs').click()};
  $('epImgs').onchange=function(){var fl=Array.prototype.slice.call(this.files);this.value='';epAddImgs(fl,false,false)};
  $('epAddCam').onclick=async function(){try{await camOpen({multi:true,detect:true,onShot:function(b){return epAddImgs([b],true,true)}})}catch(e){camFail(e,function(){$('epImgs').click()})}};
  $('epGrid').onclick=async function(e){
   var card=e.target.closest('[data-sel]');
   if(card&&!e.target.closest('button')){EP.sel=+card.dataset.sel;epRender();return}
   var bt=e.target.closest('button');if(!bt)return;var i=+bt.dataset.i,a=bt.dataset.a,it=EP.items[i];if(!it)return;EP.sel=i;
   if(a==='rm'){EP.items.splice(i,1);EP.sel=Math.min(i,EP.items.length-1)}else if(a==='up'||a==='dn'){EP.sel=moveItem(EP.items,i,a)}
   else if(a==='rl'||a==='rr'){var d=a==='rr'?90:270;
    if(it.t==='pdf'){it.rot=(it.rot+d)%360}else{it.blob=await rotBlob(it.blob,d);it.orig=await rotBlob(it.orig,d);it.thumb=thumbOfCanvas(await blobToCanvas(it.blob,300))}}
   else if(a==='ed'){
    try{var src=it.orig;
     if(it.t==='pdf'){msg.textContent='Preparing page…';var pg=await EP.doc.getPage(it.idx+1),rot=(pg.rotate+it.rot)%360,vp=pg.getViewport({scale:1,rotation:rot}),vv=pg.getViewport({scale:Math.min(3,2000/Math.max(vp.width,vp.height)),rotation:rot}),c=document.createElement('canvas');c.width=Math.round(vv.width);c.height=Math.round(vv.height);
      var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);await pg.render({canvasContext:x,viewport:vv}).promise;src=await canvasToBlob(c,0.92);msg.textContent=''}
     return edOpen(src,async function(bl,cv){EP.items[i]={t:'img',orig:src,blob:bl,thumb:thumbOfCanvas(cv)};EP.sel=i;epRender()},{filter:'orig'})}
    catch(er){msg.textContent='';return err('This page could not be opened for editing.')}}
   epRender()};
  async function epDoRot(d){var it=EP.items[EP.sel];if(!it)return;
   if(it.t==='pdf'){it.rot=((it.rot||0)+d)%360}else{it.blob=await rotBlob(it.blob,d);it.orig=await rotBlob(it.orig,d);it.thumb=thumbOfCanvas(await blobToCanvas(it.blob,300))}
   epRender()}
  if($('epPrevRL'))$('epPrevRL').onclick=function(){epDoRot(270)};
  if($('epPrevRR'))$('epPrevRR').onclick=function(){epDoRot(90)};
  if($('epPrevEd'))$('epPrevEd').onclick=async function(){var it=EP.items[EP.sel];if(!it)return;
   try{var src=it.orig;
    if(it.t==='pdf'){msg.textContent='Preparing page…';var pg=await EP.doc.getPage(it.idx+1),rot=(pg.rotate+(it.rot||0))%360,vp=pg.getViewport({scale:1,rotation:rot}),vv=pg.getViewport({scale:Math.min(3,2000/Math.max(vp.width,vp.height)),rotation:rot}),c=document.createElement('canvas');c.width=Math.round(vv.width);c.height=Math.round(vv.height);
     var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);await pg.render({canvasContext:x,viewport:vv}).promise;src=await canvasToBlob(c,0.92);msg.textContent=''}
    edOpen(src,async function(bl,cv){EP.items[EP.sel]={t:'img',orig:src,blob:bl,thumb:thumbOfCanvas(cv)};epRender()},{filter:'orig'})}
   catch(er){msg.textContent='';err('This page could not be opened for editing.')}};
  if($('epPrevFs'))$('epPrevFs').onclick=function(){var s=$('epPrevImg')&&$('epPrevImg').src;if(s)lbShow(s)};
  if($('epPrevStage'))$('epPrevStage').ondblclick=function(){var s=$('epPrevImg')&&$('epPrevImg').src;if(s)lbShow(s)};
  $('epClear').onclick=function(){PS.clear('pdfedit',true)};

  $('epRun').onclick=async function(){
   if(!EP.items.length)return;var bt=this;bt.disabled=true;msg.textContent='Saving PDF…';
   try{await loadFor('pdf');var PD=PDFLib.PDFDocument,out=await PD.create(),srcDoc=null;
    if(EP.bytes&&EP.items.some(function(t){return t.t==='pdf'})){try{srcDoc=await PD.load(EP.bytes)}catch(e){bt.disabled=false;return err('This PDF is protected or damaged and cannot be saved after editing.')}}
    for(var n=0;n<EP.items.length;n++){var it=EP.items[n];msg.textContent='Saving page '+(n+1)+' of '+EP.items.length+'…';
     if(it.t==='pdf'){var cp=await out.copyPages(srcDoc,[it.idx]),p=cp[0];if(it.rot)p.setRotation(PDFLib.degrees((((p.getRotation().angle+it.rot)%360)+360)%360));out.addPage(p)}
     else{var J=await jpgInfo(it.blob,QM.bal);addImgPage(out,await out.embedJpg(J.bytes),J,'a4')}}
    showPdf($('scout2'),await out.save(),(EP.doc?EP.name+'-edited':'document')+'.pdf',EP.items.length)}
   catch(e){err('Could not save the PDF. Try fewer pages.')}
   bt.disabled=!EP.items.length};
 })();


 /* ===== Image gallery editor: big preview box + crop / rotate / flip, small thumbnails below ===== */
 var GAL=(function(){
  var items=[],sel=-1,uid=0,bigUrl=null,crop=null,aspect=null,drag=null,tok=0,NW=1,NH=1,MAXI=30;
  var box=$('gal'),im=$('galImg'),svg=$('galSvg'),strip=$('galStrip'),info=$('galInfo');
  function T(f){return /^image\/(jpeg|png|webp)$/.test(f.type)?f.type:'image/png'}
  function toBlob(c,mime){return new Promise(function(r){c.toBlob(r,mime,0.95)})}
  async function thumbOf(f){
   var L=await loadImg(f),i=L.i,k=Math.min(1,150/Math.max(i.naturalWidth,i.naturalHeight)),c=document.createElement('canvas');
   c.width=Math.max(1,Math.round(i.naturalWidth*k));c.height=Math.max(1,Math.round(i.naturalHeight*k));
   var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(i,0,0,c.width,c.height);URL.revokeObjectURL(L.u);
   return c.toDataURL('image/jpeg',0.72);
  }
  function cur(){return items[sel]||null}
  async function sync(){
   var my=++tok;resetBatch();
   if(!items.length){clear();hideBadge();return}
   $('thumb').hidden=true;drop.hidden=true;
   var kinds=items.map(function(it){return it.kind});
   if(items.length===1){
    var f=items[0].f,L=await loadImg(f);
    if(my!==tok){URL.revokeObjectURL(L.u);return}
    file=f;img=L.i;if(tu)URL.revokeObjectURL(tu);tu=L.u;ratio=img.naturalWidth/img.naturalHeight;
    if(!D.w){$('rw').value=img.naturalWidth;$('rh').value=img.naturalHeight}
    showBadge('Detected format: <b>'+(LBL[kinds[0]]||kinds[0])+'</b>'+(kinds[0]==='heic'?' · converted to JPG so it works everywhere':''));
   }else{
    batch=items.map(function(it){return it.f});file=batch[0];
    showBadge('Detected formats: <b>'+kindsText(kinds)+'</b>');
   }
   runs(true);upd();setTimeout(updateResizeOverlay,40);msg.textContent='';$('done').classList.remove('show');
  }
  function drawInfo(){
   var it=cur();if(!it){info.textContent='';return}
   var tot=items.reduce(function(s,x){return s+x.f.size},0);
   info.innerHTML='<b>'+esc(it.f.name)+'</b> · '+size(it.f.size)+' · '+(it.w||'?')+'×'+(it.h||'?')+(it.edited?' · edited':'')+'<br><small>'+items.length+' image'+(items.length>1?'s':'')+' · '+size(tot)+' total · tap a small picture to edit it</small>';
  }
  function show(){
   box.hidden=!items.length;
   if(!items.length)return;
   if(sel<0||sel>=items.length)sel=0;
   var it=cur();
   if(bigUrl)URL.revokeObjectURL(bigUrl);bigUrl=URL.createObjectURL(it.f);
   cropOff();im.onload=function(){it.w=im.naturalWidth;it.h=im.naturalHeight;drawInfo()};im.onload=function(){drawInfo();setTimeout(updateResizeOverlay,30)};im.src=bigUrl;drawInfo();
   strip.innerHTML=items.map(function(x,i){return '<div class="gal-th'+(i===sel?' on':'')+'" data-i="'+i+'"><img src="'+x.th+'" alt="Image '+(i+1)+'"><button type="button" class="gal-x" data-x="'+i+'" aria-label="Remove image '+(i+1)+'">✕</button></div>'}).join('');
   $('galReset').disabled=!it.edited;
  }
  async function add(list){
   inp.value='';list=Array.from(list||[]);if(!list.length)return;
   var room=MAXI-items.length;if(room<=0)return err('You can add up to '+MAXI+' images at once.');
   var r;try{r=await normAll(list)}catch(e){return err('These images could not be read. Please try again.')}
   var pairs=[];r.files.forEach(function(f,i){if(/^image\//.test(f.type))pairs.push([f,r.kinds[i]])});
   if(!pairs.length)return err('Please choose image files (JPG, PNG, WebP or iPhone HEIC).');
   var cut=pairs.length>room;pairs=pairs.slice(0,room);var first=items.length,bad=r.bad;
   for(var k=0;k<pairs.length;k++){
    try{items.push({id:++uid,f:pairs[k][0],orig:pairs[k][0],kind:pairs[k][1],th:await thumbOf(pairs[k][0]),edited:false})}catch(e){bad++}
   }
   if(items.length<=first){return err('These images could not be read. Please try again.')}
   sel=first;show();await sync();
   if(bad||cut)err((bad?bad+' file'+(bad>1?'s':'')+' could not be read. ':'')+(cut?'Only '+MAXI+' images can be added at once.':''));
  }
  function clearAll(){items=[];sel=-1;tok++;cropOff();if(bigUrl){URL.revokeObjectURL(bigUrl);bigUrl=null}im.removeAttribute('src');strip.innerHTML='';box.hidden=true;resetBatch();clear();hideBadge()}
  async function replaceFile(draw,w,h){
   var it=cur();if(!it)return;
   var c=document.createElement('canvas');c.width=Math.max(1,Math.round(w));c.height=Math.max(1,Math.round(h));
   var L=await loadImg(it.f),mime=T(it.f),x=c.getContext('2d');
   if(mime==='image/jpeg'){x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height)}
   draw(x,L.i,c.width,c.height);URL.revokeObjectURL(L.u);
   var bl=await toBlob(c,mime);c.width=c.height=1;if(!bl)throw Error('encode');
   var name=it.f.name;if(mime!==it.f.type)name=name.replace(/\.[^.]+$/,'')+(mime==='image/png'?'.png':'.jpg');
   it.f=new File([bl],name,{type:mime,lastModified:Date.now()});it.edited=true;it.th=await thumbOf(it.f);
  }
  async function edit(draw,w,h){
   try{await replaceFile(draw,w,h)}catch(e){return err('Could not edit this image. Please try another one.')}
   show();await sync();
  }
  function rot(dir){
   var it=cur();if(!it)return;var w=im.naturalWidth,h=im.naturalHeight;
   edit(function(x,i,cw,ch){x.translate(cw/2,ch/2);x.rotate(dir*Math.PI/2);x.drawImage(i,-w/2,-h/2,w,h)},h,w);
  }
  function flip(){
   var w=im.naturalWidth,h=im.naturalHeight;
   edit(function(x,i,cw,ch){x.translate(cw,0);x.scale(-1,1);x.drawImage(i,0,0,cw,ch)},w,h);
  }
  // ---------- crop ----------
  function cropOn(){
   if(!cur())return;NW=im.naturalWidth;NH=im.naturalHeight;crop={l:.06,t:.06,r:.94,b:.94};setAspect(aspect);
   $('galCropBar').hidden=false;$('galTools').hidden=true;var ro=$('resizeCropOverlay');if(ro)ro.style.display='none';svg.removeAttribute('hidden');paint();
  }
  function cropOff(){crop=null;drag=null;$('galCropBar').hidden=true;$('galTools').hidden=false;svg.setAttribute('hidden','');svg.innerHTML='';if(typeof updateResizeOverlay==='function')setTimeout(updateResizeOverlay,0)}
  function setAspect(a){
   aspect=a;Q('[data-galar]').forEach(function(b){b.setAttribute('aria-pressed',(b.dataset.galar==='free'?null:+b.dataset.galar)===a?'true':'false')});
   if(!crop||!a){paint();return}
   var cx=(crop.l+crop.r)/2,cy=(crop.t+crop.b)/2,w,h;
   if(a>=NW/NH){w=0.9;h=w*NW/a/NH}else{h=0.9;w=h*NH*a/NW}
   cx=Math.min(1-w/2,Math.max(w/2,cx));cy=Math.min(1-h/2,Math.max(h/2,cy));
   crop={l:cx-w/2,r:cx+w/2,t:cy-h/2,b:cy+h/2};paint();
  }
  function paint(){
   if(!crop)return;var dw=im.clientWidth,dh=im.clientHeight;if(!dw||!dh)return;
   svg.setAttribute('width',dw);svg.setAttribute('height',dh);svg.setAttribute('viewBox','0 0 '+dw+' '+dh);
   var l=crop.l*dw,t=crop.t*dh,r=crop.r*dw,b=crop.b*dh,h='<path fill="rgba(0,0,0,.5)" fill-rule="evenodd" d="M0,0H'+dw+'V'+dh+'H0Z M'+l+','+t+'H'+r+'V'+b+'H'+l+'Z"/>';
   h+='<rect data-mv="1" x="'+l+'" y="'+t+'" width="'+(r-l)+'" height="'+(b-t)+'" fill="rgba(0,0,0,0.001)" stroke="#fff" stroke-width="2" style="cursor:move"/>';
   h+='<path d="M'+(l+(r-l)/3)+','+t+'V'+b+'M'+(l+2*(r-l)/3)+','+t+'V'+b+'M'+l+','+(t+(b-t)/3)+'H'+r+'M'+l+','+(t+2*(b-t)/3)+'H'+r+'" stroke="rgba(255,255,255,.45)" stroke-width="1" fill="none" pointer-events="none"/>';
   var P=[[l,t],[(l+r)/2,t],[r,t],[r,(t+b)/2],[r,b],[(l+r)/2,b],[l,b],[l,(t+b)/2]];
   P.forEach(function(p,i){h+='<circle data-h="'+i+'" cx="'+p[0]+'" cy="'+p[1]+'" r="24" fill="rgba(0,0,0,0.001)" style="cursor:pointer"/><circle cx="'+p[0]+'" cy="'+p[1]+'" r="8" fill="#1e88e5" stroke="#fff" stroke-width="2.5" pointer-events="none"/>'});
   svg.innerHTML=h;
  }
  function inb(r){return r.l>=-1e-6&&r.t>=-1e-6&&r.r<=1+1e-6&&r.b<=1+1e-6&&r.r-r.l>=0.04&&r.b-r.t>=0.04}
  function move(e){
   if(!drag||!crop)return;var rc=svg.getBoundingClientRect(),px=Math.min(1,Math.max(0,(e.clientX-rc.left)/rc.width)),py=Math.min(1,Math.max(0,(e.clientY-rc.top)/rc.height)),r;
   if(drag.k==='m'){
    var dx=px-drag.px,dy=py-drag.py,w=drag.r.r-drag.r.l,h=drag.r.b-drag.r.t,l=Math.min(1-w,Math.max(0,drag.r.l+dx)),t=Math.min(1-h,Math.max(0,drag.r.t+dy));
    crop={l:l,t:t,r:l+w,b:t+h};paint();return;
   }
   r={l:crop.l,t:crop.t,r:crop.r,b:crop.b};var hh=drag.h;
   if(hh===0||hh===6||hh===7)r.l=Math.min(px,r.r-0.04);
   if(hh===2||hh===3||hh===4)r.r=Math.max(px,r.l+0.04);
   if(hh===0||hh===1||hh===2)r.t=Math.min(py,r.b-0.04);
   if(hh===4||hh===5||hh===6)r.b=Math.max(py,r.t+0.04);
   if(aspect){
    var w2=(r.r-r.l)*NW,h2=(r.b-r.t)*NH;
    if(hh%2===0){var hn=w2/aspect/NH;if(hh===0||hh===2)r.t=r.b-hn;else r.b=r.t+hn}
    else if(hh===1||hh===5){var wn=h2*aspect/NW,c=(r.l+r.r)/2;r.l=c-wn/2;r.r=c+wn/2}
    else{var hn2=w2/aspect/NH,c2=(r.t+r.b)/2;r.t=c2-hn2/2;r.b=c2+hn2/2}
    if(!inb(r))return;
   }
   crop=r;paint();
  }
  svg.addEventListener('pointerdown',function(e){
   if(!crop)return;var t=e.target,rc=svg.getBoundingClientRect();
   if(t.dataset&&t.dataset.h!==undefined)drag={k:'h',h:+t.dataset.h};
   else if(t.dataset&&t.dataset.mv)drag={k:'m',px:(e.clientX-rc.left)/rc.width,py:(e.clientY-rc.top)/rc.height,r:{l:crop.l,t:crop.t,r:crop.r,b:crop.b}};
   else return;
   try{svg.setPointerCapture(e.pointerId)}catch(x){}e.preventDefault();
  });
  svg.addEventListener('pointermove',move);
  ['pointerup','pointercancel'].forEach(function(v){svg.addEventListener(v,function(){drag=null})});
  window.addEventListener('resize',paint);
  function applyCrop(){
   if(!crop)return;var c=crop,sx=c.l*NW,sy=c.t*NH,sw=(c.r-c.l)*NW,sh=(c.b-c.t)*NH;
   edit(function(x,i,cw,ch){x.drawImage(i,sx,sy,sw,sh,0,0,cw,ch)},sw,sh);
  }
  // ---------- wiring ----------
  $('galRl').onclick=function(){rot(-1)};$('galRr').onclick=function(){rot(1)};$('galFlip').onclick=flip;
  var cropEditorOpen=cropOn,cropEditorClose=cropOff;window.cropEditorOpen=cropOn;window.cropEditorClose=cropOff;
  $('galCropOk').onclick=applyCrop;$('galCropNo').onclick=function(){cropOff();setResizeMode('fit')};
  $('galReset').onclick=function(){var it=cur();if(!it||!it.edited)return;it.f=it.orig;it.edited=false;thumbOf(it.f).then(function(t){it.th=t;show();sync()})};
  $('galAdd').onclick=function(){inp.click()};
  $('galDel').onclick=function(){if(!cur())return;items.splice(sel,1);if(!items.length)return clearAll();sel=Math.min(sel,items.length-1);show();sync()};
  Q('#resizeSizePresets [data-galar]').forEach(function(b){b.onclick=function(){
   var a=b.dataset.galar==='free'?null:+b.dataset.galar;
   Q('#resizeSizePresets [data-galar]').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false');x.classList.toggle('active',x===b)});
   if(b.dataset.cropW&&b.dataset.cropH){
    $('rw').value=b.dataset.cropW;$('rh').value=b.dataset.cropH;$('lock').checked=false;
    Q('[data-w]').forEach(function(x){x.setAttribute('aria-pressed',(x.dataset.w===b.dataset.cropW&&x.dataset.h===b.dataset.cropH)?'true':'false')});
   }
   if(resizeMode==='crop'){
    setAspect(a);
    if(typeof cropEditorOpen==='function'&&$('galCropBar').hidden)cropEditorOpen();
   }
   updateResizeOverlay();
   requestAnimationFrame(function(){updateResizeOverlay()});
   setTimeout(updateResizeOverlay,80);
  }});
  strip.addEventListener('click',function(e){
   var x=e.target.closest('[data-x]');
   if(x){var i=+x.dataset.x;items.splice(i,1);if(!items.length)return clearAll();sel=Math.min(sel>i?sel-1:sel,items.length-1);show();sync();return}
   var th=e.target.closest('.gal-th');if(th&&+th.dataset.i!==sel){sel=+th.dataset.i;show()}
  });
  ['dragover','dragenter'].forEach(function(v){box.addEventListener(v,function(e){e.preventDefault()})});
  box.addEventListener('drop',function(e){e.preventDefault();add(Array.prototype.slice.call(e.dataTransfer.files))});
  return {add:add,clear:clearAll};
 })();
 function pick(f){GAL.add(f?[f]:[])}
 function setBatch(l){GAL.add(l)}
})();
;
(function(){
 'use strict';
 var $=function(id){return document.getElementById(id)};
 var PS=window.PDFShared;
 var root=$('pdfSmartGallery'),stage=$('psgStage'),thumbs=$('psgThumbs'),controls=$('psgControls'),meta=$('psgMeta'),title=$('psgTitle'),hint=$('psgHint'),note=$('psgNote');
 if(!root||!stage||!PS)return;
 // One gallery element serves every shared PDF tool. It is moved into the visible tool's slot; it is never duplicated.
 var TITLES={pdfcompress:'PDF Compress',pdfmerge:'PDF Merge',pdfsplit:'PDF Split',pdfimg:'PDF to Image',pdfedit:'PDF Edit Gallery',scan:'Scan Document Gallery',imgpdf:'Image to PDF Gallery'};
 var HINTS={pdfcompress:'Preview of the selected PDF. The compression mode is chosen below.',pdfsplit:'Tick pages to extract them, or tap a thumbnail to preview a page. The page box below follows your ticks.',pdfimg:'Every page of this PDF is converted to an image.',pdfmerge:'Use ↑ / ↓ to change the order in which the PDFs are merged.',scan:'Only scanned images appear here. Select a page to rotate, crop/edit, reorder or delete it.',imgpdf:'Only selected photos appear here. Rotate or delete photos before creating the PDF.'};
 var EDIT_HINT='Tap a page to select it. Touch and hold a page or thumbnail, then drag it up or down to change the order. Editing buttons are below the gallery.';
 var NOTE_TEXT='Edit PDF has unsaved page changes. This tool uses the original PDF, not the edited version.';
 var MAXPREV=100;
 var activeKey=PS.tool,items=[],active=0,renderToken=0,scrollTick=0,splitSelected=new Set(),splitReady=false,lastEdit=null,curTotal=0,curName='';
 var pdfEditGalleryUrls=[],pdfEditPreviewGeneration=0;
 function fmt(n){return n>=1048576?(n/1048576).toFixed(2)+' MB':(n/1024).toFixed(1)+' KB'}
 function isShared(k){return !!TITLES[k]}
 function hideGallery(){root.hidden=true}
 function showGallery(){root.hidden=false}
 function clearView(){stage.innerHTML='';thumbs.innerHTML='';controls.innerHTML=''}
 function setNote(t){if(!note)return;note.textContent=t||'';note.hidden=!t}
 function short(n){return n.length>16?n.slice(0,15)+'…':n}
 // keeps scrolling inside the gallery instead of moving the whole page
 function centerIn(box,el,axis){var b=box.getBoundingClientRect(),r=el.getBoundingClientRect();if(axis==='x')box.scrollLeft+=(r.left+r.width/2)-(b.left+b.width/2);else box.scrollTop+=(r.top+r.height/2)-(b.top+b.height/2)}
 // identical page + thumbnail markup for every tool (this is the Edit PDF gallery markup)
 function makeNode(i,labelText,altText,loading){
  var page=document.createElement('div');page.className='psg-page'+(i===active?' psg-current':'');page.dataset.index=i;if(loading)page.dataset.loading=loading;
  var im=document.createElement('img');im.alt=altText||labelText;page.appendChild(im);stage.appendChild(page);
  var th=document.createElement('button');th.type='button';th.className='psg-thumb'+(i===active?' active':'');th.dataset.index=i;
  var ti=document.createElement('img');ti.alt='';th.appendChild(ti);
  var lb=document.createElement('span');lb.textContent=labelText;th.appendChild(lb);thumbs.appendChild(th);
  return {page:page,th:th,im:im,ti:ti}}
 function setImg(nd,src){nd.im.src=src;nd.ti.src=src;nd.page.classList.add('psg-ready')}

 function render(){
  renderToken++;var tok=renderToken;
  setNote('');
  if(!isShared(activeKey)){hideGallery();return}
  root.dataset.mode=activeKey;title.textContent=TITLES[activeKey];
  if(activeKey==='scan'||activeKey==='imgpdf'){renderImageMode(activeKey);return}
  if(activeKey==='pdfedit'){renderEdit();return}
  if(!PS.files.length){hideGallery();clearView();items=[];return}
  showGallery();
  if(activeKey==='pdfmerge')renderMerge(tok);else renderPages(tok)}

 /* ---- Compress / Split / PDF to Image: pages of the shared original PDF ---- */
 async function renderPages(tok){
  var f=PS.first();clearView();items=[];active=0;
  meta.textContent='Reading PDF…';hint.textContent=HINTS[activeKey]||'';
  if(PS.edit&&PS.edit.isDirty())setNote(NOTE_TEXT);
  var d;
  try{d=await PS.load(f)}catch(e){if(tok!==renderToken)return;stage.innerHTML='<div class="psg-empty">Could not preview this PDF. The file may be damaged or password-protected.</div>';meta.textContent='Preview unavailable';return}
  if(tok!==renderToken)return;
  var total=d.doc.numPages,count=Math.min(total,MAXPREV);curTotal=total;curName=f.name;
  if(activeKey==='pdfsplit'&&!splitReady){splitSelected=new Set();if(total<=MAXPREV)for(var k=0;k<count;k++)splitSelected.add(k);splitReady=true;if(total<=MAXPREV)setTimeout(function(){if(tok===renderToken)updateSplitSpec()},0)}
  if(total>MAXPREV)hint.textContent='Showing the first '+MAXPREV+' of '+total+' pages. '+(activeKey==='pdfsplit'?'Type other pages in the box below.':'All pages are still processed.');
  for(var n=1;n<=count;n++)(function(n){
   var i=n-1,nd=makeNode(i,'Page '+n,'Page '+n,'Loading page '+n+'…');
   if(activeKey==='pdfsplit'){var cb=document.createElement('input');cb.type='checkbox';cb.setAttribute('aria-label','Select page '+n);cb.checked=splitSelected.has(i);cb.addEventListener('click',function(e){e.stopPropagation();splitSelected[cb.checked?'add':'delete'](i);updateSplitSpec()});nd.th.insertBefore(cb,nd.th.firstChild)}
   nd.th.addEventListener('click',function(){select(i,true)});nd.page.addEventListener('click',function(){select(i,false)});
   items.push(nd)})(n);
  if(activeKey==='pdfsplit')drawSplitControls();
  select(0,false);
  for(var m=1;m<=count;m++){
   var src;try{src=await PS.renderPage(f,m)}catch(e){if(tok!==renderToken)return;items[m-1].page.dataset.loading='Preview unavailable';continue}
   if(tok!==renderToken)return;setImg(items[m-1],src)}}

 /* ---- Merge: first page of each file, in merge order ---- */
 async function renderMerge(tok){
  var files=PS.files.slice();clearView();items=[];active=0;
  hint.textContent=HINTS.pdfmerge;
  if(PS.edit&&PS.edit.isDirty())setNote(NOTE_TEXT);
  curTotal=files.length;curName='';
  files.forEach(function(f,i){fileCard(f,i,files.length)});
  files.forEach(function(f,i){
   var nd=makeNode(i,(i+1)+'. '+short(f.name),(i+1)+'. '+f.name,'Loading…');
   nd.th.addEventListener('click',function(){select(i,true)});nd.page.addEventListener('click',function(){select(i,false)});items.push(nd)});
  select(0,false);
  for(var i=0;i<files.length;i++){
   var src;try{src=await PS.renderPage(files[i],1)}catch(e){if(tok!==renderToken)return;items[i].page.dataset.loading='Preview unavailable';continue}
   if(tok!==renderToken)return;setImg(items[i],src)}}
 function fileCard(file,i,total){
  var d=document.createElement('div');d.className='psg-file-card';
  d.innerHTML='<span class="psg-file-name"></span><button type="button" class="btn" data-move="up" aria-label="Move earlier">↑</button><button type="button" class="btn" data-move="down" aria-label="Move later">↓</button>';
  d.querySelector('.psg-file-name').textContent=(i+1)+'. '+file.name+' · '+fmt(file.size);
  var up=d.querySelector('[data-move="up"]'),dn=d.querySelector('[data-move="down"]');up.disabled=i===0;dn.disabled=i===total-1;
  up.onclick=function(){PS.move(i,-1)};dn.onclick=function(){PS.move(i,1)};controls.appendChild(d)}

 function select(i,scroll){
  if(!items.length)return;
  active=Math.max(0,Math.min(items.length-1,i));
  items.forEach(function(nd,k){nd.page.classList.toggle('psg-current',k===active);nd.th.classList.toggle('active',k===active)});
  if(activeKey==='pdfmerge'){var mf=PS.files[active];meta.textContent=PS.files.length+' PDF file(s) · '+(active+1)+'. '+(mf?mf.name:'')+' · first page of each file'}
  else{var f=PS.first();meta.textContent='Page '+(active+1)+' of '+curTotal+' · '+curName+(f?' · '+fmt(f.size):'')}
  if(scroll){centerIn(stage,items[active].page,'y');centerIn(thumbs.parentNode,items[active].th,'x')}}
 function step(d){
  if(activeKey==='pdfedit'){var cards=document.querySelectorAll('#epGrid [data-sel]');var i=Math.max(0,Math.min(cards.length-1,active+d));if(cards[i])cards[i].click()}
  else select(active+d,true)}
 $('psgPrev').onclick=function(){step(-1)};$('psgNext').onclick=function(){step(1)};
 stage.addEventListener('scroll',function(){
  if(activeKey==='pdfedit'||!items.length||scrollTick)return;
  scrollTick=requestAnimationFrame(function(){scrollTick=0;var mid=stage.getBoundingClientRect().top+stage.clientHeight/2,best=0,dist=Infinity;items.forEach(function(nd,i){var r=nd.page.getBoundingClientRect(),dd=Math.abs((r.top+r.bottom)/2-mid);if(dd<dist){dist=dd;best=i}});if(best!==active)select(best,false)})});

 /* ---- Image-based modes: same gallery shell, existing Scan/Image-to-PDF state remains authoritative ---- */
 var imageModeData={scan:null,imgpdf:null};
 document.addEventListener('lovepdfi:image-gallery-update',function(ev){
  var d=ev.detail||{};if(!d.mode||!imageModeData.hasOwnProperty(d.mode))return;imageModeData[d.mode]=d;
  if(activeKey===d.mode){renderToken++;renderImageMode(d.mode)}
 });
 function renderImageMode(key){
  var d=imageModeData[key];clearView();items=[];active=0;setNote('');showGallery();
  title.textContent=TITLES[key];hint.textContent=HINTS[key]||'';
  if(!d||!Array.isArray(d.items)||!d.items.length){meta.textContent=key==='scan'?'No scanned pages yet':'No photos selected yet';stage.innerHTML='<div class="psg-empty">'+(key==='scan'?'Scan a page or add images to start.':'Select images or take photos to start.')+'</div>';return}
  meta.textContent=d.items.length+(key==='scan'?' scanned page(s)':' photo(s)')+' · same shared gallery';
  var gen=renderToken;
  d.items.forEach(function(it,i){
   var nd=makeNode(i,(i+1)+'. '+(it.name||((key==='scan'?'Page ':'Photo ')+(i+1))),(it.name||'Image '+(i+1)));
   nd.page.classList.add('psg-ready');nd.im.src=it.src||it.thumb||'';nd.ti.src=it.src||it.thumb||'';
   function choose(){if(gen!==renderToken)return;active=i;if(typeof d.select==='function')d.select(i);items.forEach(function(x,k){x.page.classList.toggle('psg-current',k===i);x.th.classList.toggle('active',k===i)});}
   nd.page.addEventListener('click',choose);nd.th.addEventListener('click',choose);items.push(nd);
  });
  var acts=key==='scan'
   ?[['up','↑','Move earlier'],['dn','↓','Move later'],['rl','↺','Rotate left'],['rr','↻','Rotate right'],['ed','✎','Crop/edit'],['rm','×','Delete page']]
   :[['up','↑','Move earlier'],['dn','↓','Move later'],['rl','↺','Rotate left'],['rr','↻','Rotate right'],['rm','×','Delete photo']];
  acts.forEach(function(a){var b=document.createElement('button');b.type='button';b.className='btn'+(a[0]==='rm'?' red':'');b.textContent=a[1];b.title=a[2];b.setAttribute('aria-label',a[2]);b.onclick=function(){if(typeof d.action==='function')d.action(active,a[0])};controls.appendChild(b)});
  active=Math.max(0,Math.min(items.length-1,Number(d.selected)||0));items.forEach(function(x,k){x.page.classList.toggle('psg-current',k===active);x.th.classList.toggle('active',k===active)});
  if(items[active])centerIn(stage,items[active].page,'y');
 }

 /* ---- Split controls (tool-specific; they only write the page box) ---- */
 function drawSplitControls(){
  controls.innerHTML='<span class="psg-count" id="psgSelectedCount"></span><button class="btn" type="button" id="psgAll">Select all</button><button class="btn" type="button" id="psgNone">Select none</button>';
  $('psgAll').onclick=function(){splitSelected=new Set(items.map(function(_,i){return i}));syncChecks();updateSplitSpec()};
  $('psgNone').onclick=function(){splitSelected.clear();syncChecks();updateSplitSpec()};
  syncChecks();updateSplitCount()}
 function syncChecks(){Array.from(thumbs.children).forEach(function(t,i){var c=t.querySelector('input');if(c)c.checked=splitSelected.has(i)})}
 function updateSplitCount(){var c=$('psgSelectedCount');if(c)c.textContent=splitSelected.size+' page(s) selected'}
 function updateSplitSpec(){
  var nums=Array.from(splitSelected).sort(function(a,b){return a-b}).map(function(i){return i+1});var ranges=[];
  for(var i=0;i<nums.length;){var j=i;while(j+1<nums.length&&nums[j+1]===nums[j]+1)j++;ranges.push(nums[i]===nums[j]?''+nums[i]:nums[i]+'-'+nums[j]);i=j+1}
  if($('pagespec'))$('pagespec').value=ranges.join(', ');
  updateSplitCount();
  if($('pdfsrun'))$('pdfsrun').disabled=!PS.first()||!splitSelected.size}

 /* ---- Edit PDF: working copy (EP) of the shared PDF, drawn with the same markup ---- */
 function renderEdit(){
  var pending=PS.edit&&PS.edit.pending(),has=lastEdit&&lastEdit.items&&lastEdit.items.length;
  if(!has&&!pending){hideGallery();clearView();items=[];return}
  showGallery();
  if(pending){clearView();items=[];meta.textContent='Preparing pages for editing…';hint.textContent=EDIT_HINT;stage.innerHTML='<div class="psg-empty">Preparing pages for editing…</div>';return}
  drawEdit(lastEdit)}
 function drawEdit(data){
  pdfEditGalleryUrls.forEach(function(u){try{URL.revokeObjectURL(u)}catch(e){}});pdfEditGalleryUrls=[];
  var generation=++pdfEditPreviewGeneration,arr=data.items||[];
  items=[];clearView();title.textContent='PDF Edit Gallery';
  meta.textContent=arr.length+' page(s)'+(data.name?' · '+data.name:'')+(arr.length?(data.edited?' · working version (edited, not saved yet)':' · original pages'):'');
  hint.textContent=EDIT_HINT;
  if(!arr.length){stage.innerHTML='<div class="psg-empty">Select a PDF or add images to see the pages here.</div>';return}
  active=Math.max(0,Math.min(arr.length-1,Number(data.selected)||0));
  arr.forEach(function(it,i){
   var nd=makeNode(i,it.label||('Page '+(i+1)),it.label||('Page '+(i+1)));
   if(it.blob){var fullUrl=URL.createObjectURL(it.blob);pdfEditGalleryUrls.push(fullUrl);nd.im.src=fullUrl}else{nd.im.src=it.thumb||''}
   nd.ti.src=it.thumb||'';nd.page.classList.add('psg-ready');
   if(it.rot&&!it.blob){pdfEditRotatedPreview(it.thumb,it.rot,function(rotated){if(generation!==pdfEditPreviewGeneration)return;nd.im.src=rotated;nd.ti.src=rotated})}
   nd.th.addEventListener('click',function(){var cards=document.querySelectorAll('#epGrid [data-sel]');if(cards[i])cards[i].click()});
   nd.page.addEventListener('click',function(){var cards=document.querySelectorAll('#epGrid [data-sel]');if(cards[i])cards[i].click()})});
  var selected=stage.children[active];if(selected)centerIn(stage,selected,'y')}
 // Rotate PDF page previews in their actual pixel dimensions, not just the thumbnail CSS.
 function pdfEditRotatedPreview(src,degrees,done){
  var angle=((Number(degrees)||0)%360+360)%360;
  if(!angle){done(src);return}
  var picture=new Image();
  picture.onload=function(){
   var canvas=document.createElement('canvas'),quarter=angle===90||angle===270;
   canvas.width=quarter?picture.naturalHeight:picture.naturalWidth;
   canvas.height=quarter?picture.naturalWidth:picture.naturalHeight;
   var ctx=canvas.getContext('2d');ctx.translate(canvas.width/2,canvas.height/2);
   ctx.rotate(angle*Math.PI/180);
   ctx.drawImage(picture,-picture.naturalWidth/2,-picture.naturalHeight/2);
   done(canvas.toDataURL('image/jpeg',0.92));
  };
  picture.onerror=function(){done(src)};
  picture.src=src;
 }
 // Edit PDF reports its working pages here whenever they change; they are drawn only while Edit PDF is the visible tool.
 document.addEventListener('lovepdfi:pdfedit-gallery',function(ev){
  lastEdit=ev.detail||null;
  if(activeKey==='pdfedit'){renderToken++;renderEdit()}
 });

 // Visible edit actions control the existing selected-page handlers; no duplicate gallery is displayed.
 var epBar=document.getElementById('pdfEditActionBar');
 if(epBar)epBar.addEventListener('click',function(e){
  var b=e.target.closest('[data-ep-action]');if(!b||activeKey!=='pdfedit')return;
  var i=active||0,card=document.querySelector('#epGrid [data-sel="'+i+'"]');if(!card)return;
  var old=card.querySelector('button[data-a="'+b.dataset.epAction+'"]');if(old)old.click();
 });

 // Edit PDF only: long-press a page/thumbnail, then drag it to reorder.
 (function enablePdfEditTouchReorder(){
  var press=null,holdTimer=null,dragging=false,source=null,target=null,startX=0,startY=0;
  function clearMarks(){root.querySelectorAll('.psg-dragging,.psg-drop-target').forEach(function(el){el.classList.remove('psg-dragging','psg-drop-target')})}
  function stopTimer(){if(holdTimer){clearTimeout(holdTimer);holdTimer=null}}
  function cancel(){stopTimer();if(source&&source.releasePointerCapture&&press){try{source.releasePointerCapture(press.pointerId)}catch(e){}}press=null;source=null;target=null;dragging=false;clearMarks()}
  root.addEventListener('pointerdown',function(e){
   if(activeKey!=='pdfedit'||e.button!==0)return;
   var el=e.target.closest('.psg-page,.psg-thumb');if(!el)return;
   var idx=Number(el.dataset.index);if(!Number.isInteger(idx))return;
   cancel();press=e;source=el;target=el;startX=e.clientX;startY=e.clientY;
   holdTimer=setTimeout(function(){if(!press)return;dragging=true;source.classList.add('psg-dragging');source.setPointerCapture&&source.setPointerCapture(press.pointerId)},280);
  });
  root.addEventListener('pointermove',function(e){
   if(!press)return;
   if(!dragging){if(Math.abs(e.clientX-startX)>10||Math.abs(e.clientY-startY)>10)stopTimer();return}
   e.preventDefault();var at=document.elementFromPoint(e.clientX,e.clientY),el=at&&at.closest('.psg-page,.psg-thumb');
   if(el&&root.contains(el)){var idx=Number(el.dataset.index);if(Number.isInteger(idx)){if(target&&target!==source)target.classList.remove('psg-drop-target');target=el;if(target!==source)target.classList.add('psg-drop-target')}}
  },{passive:false});
  root.addEventListener('pointerup',function(e){
   if(!press)return;stopTimer();
   if(dragging&&target){var from=Number(source.dataset.index),to=Number(target.dataset.index);clearMarks();if(Number.isInteger(from)&&Number.isInteger(to)&&from!==to)document.dispatchEvent(new CustomEvent('lovepdfi:pdfedit-reorder',{detail:{from:from,to:to}}));}
   cancel();
  });
  root.addEventListener('pointercancel',cancel);
  root.addEventListener('contextmenu',function(e){if(activeKey==='pdfedit'&&e.target.closest('.psg-page,.psg-thumb'))e.preventDefault()});
 })();

 /* ---- shared selection changes -> redraw; tool switches -> move the gallery, keep the selection ---- */
 PS.on(function(kind){
  if(kind==='select'||kind==='clear'){splitSelected=new Set();splitReady=false}
  if(kind==='select'||kind==='clear'||kind==='order')render();
 });
 PS.onTool=function(key){
  activeKey=key;PS.tool=key;
  if(key==='scan'||key==='imgpdf')document.dispatchEvent(new CustomEvent('lovepdfi:request-image-gallery',{detail:{mode:key}}));
  if(isShared(key)){
   var sub=document.querySelector('[data-panel="pdf"] [data-subpanel="'+key+'"]'),slot=sub&&sub.querySelector('[data-psg-slot]');
   if(slot&&root.parentNode!==slot)slot.appendChild(root);
   root.dataset.mode=key}
  PS.emit('tool');
  render();
 };
 // The PDF to Image tab is a link to a standalone page; keep it in-page unless the visitor opens it in a new tab.
 var p2iLink=document.querySelector('[data-panel="pdf"] a.subtab[data-sub="pdfimg"]');
 if(p2iLink)p2iLink.addEventListener('click',function(e){if(e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||e.button!==0)return;e.preventDefault()});
 var cur=document.querySelector('[data-panel="pdf"] [data-subpanel]:not([hidden])');
 PS.onTool(cur?cur.dataset.subpanel:'pdfcompress');
})();
;
(function(){
 function placeGalleries(){
  var panel=document.querySelector('[data-panel="pdf"]'); if(!panel)return;
  panel.querySelectorAll('.subpanel[data-subpanel]').forEach(function(sub){
   var slot=sub.querySelector(':scope > .psg-slot');
   if(!slot)return;
   var key=sub.getAttribute('data-subpanel');
   var actions=sub.querySelector(':scope > .actions');
   if(!actions)return;
   /* Keep the single gallery slot directly after Select/Clear buttons; all existing handlers remain intact. */
   if(actions.nextElementSibling!==slot) actions.insertAdjacentElement('afterend',slot);
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',placeGalleries,{once:true});else placeGalleries();
 window.addEventListener('load',placeGalleries,{once:true});
})();
})();
}
